你是独立只读代码审计员。只做静态审查，不修改文件、不运行命令、不联网。

对象：Paseo-workflow 固定提交 `5fa4a8ad1083c44c92e69f0fb84bdf900bd333ee`（基线 `fa157e1ce53374d539f4b5b5aa1129eccad7cb3b`，实际父 `e4c93d3ee6ed9be7081e06596ce96411a2708bdf`），源码在 `C:\Users\KK\AppData\Local\Temp\opencode\paseo-audit-s0-r4\offline-copy`。

只读这些文件：`src/store.mjs`、`src/controller.mjs`、`src/git.mjs`、`src/policy.mjs`、`remote/p0_runner.py`。

回答以下 7 个问题，每条给 **CONFIRMED / NOT_CONFIRMED / UNCERTAIN** + `文件:行号` + 一句话理由：

1. **阶段/审批绕过**：`Store.save()` 是否仍允许调用方任意改 `stage`、`status`、`pendingHuman`、`lastB`、`p0Initial/p0Final`、`reviewers`、`history`？能否直接 `save(t,'A_COMMIT_FROZEN')` 把 `currentSha` 改成一个假值、把 `stage` 设为 `WAIT_GATE_59`，随后 `Controller.approve({gate:'5.9'})` 直接 CLOSED？
2. **初始可信根**：`Store.init()` 是否接受已处于 `WAIT_GATE_59`、带假 `currentSha`、或带伪造 `frozen`/`taskSpec` 的任务？`init` 和首次 `TASK_SPEC_CANDIDATE` 是否绑定到合法 Planner 阶段/角色？
3. **artifact 边界**：`artifact()` 的 verify、文件写入/fsync、manifest INSERT、ledger append 是否都在同一 `BEGIN IMMEDIATE` 内？同连接 fsync 回调篡改、第二 SQLite 连接竞争、注册事件失败、预置孤儿文件是否都能 fail-closed/回滚？文件系统与 SQLite 非原子性是否被错误声称已原子化？
4. **TASK_SPEC/冻结**：`frozen` 是否在 `save` 不可替换？TASK_SPEC 与 SHA 是否必须同时存在/缺失、匹配、首次只能由 `TASK_SPEC_CANDIDATE` 建立且之后不可改？`init`/`Controller.assertFrozenIntegrity`/`authorizeRecovery` 是否形成双重约束？`currentSha/baseSha` 是否有 Git 对象/祖先校验？
5. **解析器**：本地 `finalJsonEnvelope` 与远端 `final_json` 是否只接受唯一终止 verdict 对象？FAIL 后 PASS、双 JSON 围栏、Markdown 示例、缩进/pretty/CRLF、截断、尾随文字、OpenCode JSONL 是否会把 FAIL 误读为 PASS？多个 verdict 被拒绝是否属于安全保守行为？
6. **Git 路径**：`safeChange` 的 Cc/Cf/Default_Ignorable/Braille/Hangul 过滤是否覆盖 U+00AD/U+034F/U+180E/U+3164/U+2800/零宽字符？中文/正常文件名是否误伤？`validateStaged` 是否扫描完整 index，拒绝 base 继承的 120000 symlink/160000 gitlink、sensitive `.env`、rename/copy 与 clean worktree？
7. **回归**：新约束是否破坏 Planner→TASK_SPEC→Gate A→Gate B→Gate 5.9 的正常流程？是否引入新的 SQLite 嵌套事务、锁、死锁或孤儿文件问题？

最后给 `CODE_VERDICT: PASS / FAIL / INCONCLUSIVE`。输出不超过 1500 字。不要声称运行了测试。