# S0 remediation audit delivery

Start with delivery/AUDIT_REPORT.md (FAIL; real execution BLOCKED).
The two independent raw reports are delivery/CODEX_REPORT.md and delivery/OPENCODE_REPORT.md.
Read delivery/CROSS_REVIEW_VALIDATION.md for opinions confirmed/refuted with main-audit probes.
Machine-readable F1-F10 and R2 findings: delivery/FINDINGS.json.
Exact commands, exit codes, counts and unique test IDs: delivery/TEST_RESULTS.txt and TEST_SUMMARY.json.
S1 is PROPOSED only: delivery/S1_INSTALL_PLAN.md; installation and deployment were not executed.
Scope, unchanged original configuration hashes and source verification: delivery/SCOPE.json and FINAL_VERIFICATION.json.

Original reviewer events, inputs and receipts remain under reviewers/; failed/truncated OpenCode attempts are not valid audit reports.
Original S0 IDs come from original/S0-local-static-report.md.
Raw local logs and JUnit remain under logs/; node-full=25 pass, python-full=1 ERROR.
Supplemental defect probe PASS means the defect exists, not acceptance.
Snapshots and manifests are pinned; no moving branch checkout is used.

EVIDENCE_MANIFEST.json lists byte counts and SHA-256 for every payload file (itself excluded).
The adjacent .sha256 file authenticates the ZIP bytes for local comparison only, not a signature or external immutable anchor.
No real credentials, fixture key files, original user configs, live DBs, node_modules or services are included.
