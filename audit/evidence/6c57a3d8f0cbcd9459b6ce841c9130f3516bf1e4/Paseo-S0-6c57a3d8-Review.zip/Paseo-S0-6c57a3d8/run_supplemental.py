from __future__ import annotations
import datetime, hashlib, json, os, pathlib, re, shutil, subprocess, sys, time, xml.etree.ElementTree as ET
ROOT=pathlib.Path(__file__).resolve().parent;LOG=ROOT/'logs';LOG.mkdir(exist_ok=True)
# Correct only the audit parser's CRLF handling, without rerunning or changing the original tests.
s=json.loads((LOG/'OFFLINE_RESULTS.json').read_text(encoding='utf-8'))
text=(LOG/'python-full.stderr.log').read_text(encoding='utf-8')
names=re.findall(r'^([a-zA-Z0-9_]+ \([^\n]+\)) \.\.\. (ok|FAIL|ERROR|skipped[^\n]*)$',text,re.M)
assert len(names)==1
counts={'tests':int(re.search(r'Ran (\d+) tests?',text).group(1)),'passed':sum(r=='ok' for _,r in names),'failures':sum(r=='FAIL' for _,r in names),'errors':sum(r=='ERROR' for _,r in names),'skipped':sum(r.startswith('skipped') for _,r in names)}
assert counts['tests']==sum(counts[k] for k in ['passed','failures','errors','skipped'])
s['python']=counts;s['python_cases']=names;s['count_parser_note']='CRLF normalized for matching; original raw logs and exit code retained unchanged.'
(LOG/'OFFLINE_RESULTS.json').write_text(json.dumps(s,ensure_ascii=False,indent=2),encoding='utf-8')
suite=ET.Element('testsuite',name='unittest raw-log conversion',**{k:str(counts[k]) for k in ['tests','failures','errors','skipped']})
for name,result in names:
 c=ET.SubElement(suite,'testcase',name=name)
 if result!='ok':ET.SubElement(c,'error' if result=='ERROR' else 'failure' if result=='FAIL' else 'skipped').text=text
ET.SubElement(suite,'system-err').text=text
ET.ElementTree(suite).write(LOG/'python-full.derived.junit.xml',encoding='utf-8',xml_declaration=True)
args=[shutil.which('node'),'--test','--test-reporter=spec','--test-reporter-destination=stdout','--test-reporter=junit','--test-reporter-destination='+str(LOG/'supplemental-node.junit.xml'),str(ROOT/'probes/additional.test.mjs')]
env=os.environ.copy()
for k in list(env):
 if k.startswith('P1_'):del env[k]
for k in ['TMP','TEMP','TMPDIR']:env[k]=str(ROOT/'offline-temp')
t0=time.monotonic();started=datetime.datetime.now().astimezone().isoformat()
p=subprocess.run(args,cwd=ROOT,env=env,capture_output=True,timeout=55)
(LOG/'supplemental-node.stdout.log').write_bytes(p.stdout);(LOG/'supplemental-node.stderr.log').write_bytes(p.stderr)
r={'tag':'supplemental-node','argv':args,'cwd':str(ROOT),'started_at':started,'exit_code':p.returncode,'duration_seconds':round(time.monotonic()-t0,3),'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest(),'notes':['All network and SDK calls are local stubs. The only child processes are fixed local Node/Git fixture commands.','P1 flags are set inside supplemental test process ONLY, whose live runtime and SSH adapter are replaced; no host isolation assertion is made.','DEFECT-prefixed cases assert that a defect is present. Passing a DEFECT probe means product failure, not acceptance.','All probe-state artifacts retained for review; no manual fixture cleanup.']}
(LOG/'supplemental-node.receipt.json').write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(r,ensure_ascii=False,indent=2));print(p.stdout.decode('utf-8',errors='replace'));print(p.stderr.decode('utf-8',errors='replace'))
sys.exit(p.returncode)
