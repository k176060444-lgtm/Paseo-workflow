from __future__ import annotations
import contextlib, datetime, hashlib, importlib.util, io, json, os, pathlib, shutil, subprocess, sys, tempfile, time, unittest
from unittest.mock import patch
import xml.etree.ElementTree as ET
ROOT=pathlib.Path(__file__).resolve().parent; LOG=ROOT/'logs'; TMP=ROOT/'python-probe-state';TMP.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('p0_runner_under_audit',ROOT/'snapshot/remote/p0_runner.py');runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
notes=[]
def note(id,**kw):
    row={'id':id,**kw};notes.append(row);print('[AUDIT] '+json.dumps(row,ensure_ascii=False))
def retained(prefix):return pathlib.Path(tempfile.mkdtemp(prefix=prefix,dir=TMP))
class Supplemental(unittest.TestCase):
    def test_remote_harness_env_allowlist_filters_sentinel(self):
        with patch.dict(os.environ,{'PASEO_AUDIT_SENTINEL':'offline-synthetic-data'}):
            result=runner.child_env({});self.assertNotIn('PASEO_AUDIT_SENTINEL',result)
            p=subprocess.run([sys.executable,'-c','import os;print("PASEO_AUDIT_SENTINEL" in os.environ)'],env=result,capture_output=True,text=True,timeout=10)
            self.assertEqual(p.returncode,0);self.assertEqual(p.stdout.strip(),'False')
            note('PY-F9-HARNESS',sentinel_visible=False,real_local_child=True)
    def test_defect_remote_git_run_helper_still_inherits_unrelated_sentinel(self):
        with patch.dict(os.environ,{'PASEO_AUDIT_SENTINEL':'offline-synthetic-data'}):
            p=runner.run([sys.executable,'-c','import os;print("PASEO_AUDIT_SENTINEL" in os.environ)'],timeout=10)
            self.assertEqual(p.returncode,0);self.assertEqual(p.stdout.strip(),'True')
            note('DEFECT-PY-F9-GIT-ENV',sentinel_visible=True,helper='remote.run used by all remote Git subprocesses',real_local_child=True,meaning='PASS demonstrates residual inheritance; no real credential read')
    def test_status_reaches_platform_specific_kill_zero_primitive_without_signalling_any_real_pid(self):
        d=retained('status-');job='d'*40;(d/job).mkdir();(d/job/'pid').write_text('424242',encoding='ascii')
        cfg=d/'fixture.json';cfg.write_text(json.dumps({'nodeId':'fixture','physicalId':'fixture-physical','spool':str(d)}),encoding='utf-8')
        out=io.StringIO()
        with patch.object(sys,'argv',['p0_runner.py','status','--config',str(cfg)]),patch.object(sys,'stdin',io.StringIO(json.dumps({'jobId':job}))),patch.object(runner.os,'kill') as kill,contextlib.redirect_stdout(out):
            runner.main();kill.assert_called_once_with(424242,0)
        self.assertEqual(json.loads(out.getvalue())['status'],'RUNNING')
        note('PY-F10-STATUS-PRIMITIVE',primitive='os.kill(pid,0)',actual_os_call=False,platform=sys.platform,fixture=str(d))
    def test_cancel_on_windows_remains_uncertain_and_sends_no_signal(self):
        if sys.platform!='win32':self.skipTest('Windows-specific observation')
        d=retained('cancel-');job='e'*40;(d/job).mkdir();(d/job/'pid').write_text('424242',encoding='ascii')
        with patch.object(runner.os,'kill') as kill:
            result=runner.cancel_job({'nodeId':'fixture'},d,job);kill.assert_not_called()
        self.assertEqual(result['status'],'CANCEL_UNCERTAIN');note('PY-F2-WINDOWS-CANCEL',status=result['status'],actual_signal_sent=False)
    def test_cross_language_canonical_bytes_with_mutation_positive_control(self):
        payload={'jobId':'f'*40,'summary':'中文 "quote" \\ path\nline\ttab\u2028separator','findings':['中文','x\n\t\\"'], 'nested':{'z':True,'a':None},'n':17}
        javascript='import fs from "node:fs";import {canonical} from '+json.dumps((ROOT/'snapshot/src/policy.mjs').as_uri())+';process.stdout.write(canonical(JSON.parse(fs.readFileSync(0,"utf8"))));'
        p=subprocess.run([shutil.which('node'),'--input-type=module','-e',javascript],input=json.dumps(payload,ensure_ascii=False).encode('utf-8'),capture_output=True,timeout=10)
        self.assertEqual(p.returncode,0);original=runner.encode(payload);self.assertEqual(original,p.stdout)
        altered=dict(payload);altered['summary']+='x';self.assertNotEqual(original,runner.encode(altered));self.assertNotEqual(hashlib.sha256(original).hexdigest(),hashlib.sha256(runner.encode(altered)).hexdigest())
        note('PY-F3-CANONICAL',bytes_equal=True,mutation_detected=True,contains=['Chinese','quotes','backslash','newline','tab','U+2028'],sha256=hashlib.sha256(original).hexdigest())
    def test_remote_parser_does_not_normalize_legacy_soul_verdict(self):
        legacy=json.dumps({'verdict':'APPROVE','summary':'Fixture','findings':[]})
        self.assertEqual(runner.parse_output(legacy)['verdict'],'QUESTION')
        note('PY-F5-REMOTE-LEGACY',legacy='APPROVE',parsed='QUESTION',meaning='Fail-closed output-contract gap remains')

if __name__=='__main__':
    started=datetime.datetime.now().astimezone().isoformat();t0=time.monotonic()
    if '--diagnostic-replay' in sys.argv:
        target=ROOT/'offline-copy/remote/tests/test_runner.py';sp=importlib.util.spec_from_file_location('original_runner_test_diagnostic',target);module=importlib.util.module_from_spec(sp);sp.loader.exec_module(module)
        original_run=subprocess.run;commands=[];kept=[]
        class RetainTemporaryDirectory:
            def __init__(self,*a,**kw):self.name=str(retained('original-replay-'));kept.append(self.name)
            def __enter__(self):return self.name
            def __exit__(self,*a):return False
        def trace_run(*a,**kw):
            item={'argv':a[0] if a else kw.get('args')};commands.append(item)
            try:
                p=original_run(*a,**kw);item.update({'exit_code':p.returncode,'stdout':p.stdout.decode('utf-8',errors='replace') if isinstance(p.stdout,bytes) else p.stdout,'stderr':p.stderr.decode('utf-8',errors='replace') if isinstance(p.stderr,bytes) else p.stderr});return p
            except subprocess.CalledProcessError as e:
                item.update({'exit_code':e.returncode,'stdout':e.stdout.decode('utf-8',errors='replace') if isinstance(e.stdout,bytes) else e.stdout,'stderr':e.stderr.decode('utf-8',errors='replace') if isinstance(e.stderr,bytes) else e.stderr});raise
        stream=io.StringIO()
        with patch.object(module.tempfile,'TemporaryDirectory',RetainTemporaryDirectory),patch.object(module.subprocess,'run',trace_run):
            result=unittest.TextTestRunner(stream=stream,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(module.RemoteRunnerTests))
        text=stream.getvalue();(LOG/'python-diagnostic-replay.stderr.log').write_text(text,encoding='utf-8')
        receipt={'tag':'python-diagnostic-replay','same_original_test_id':True,'acceptance_test_modified':False,'fixture_adjustments':['Retain TemporaryDirectory instead of deleting, to avoid hiding primary failure with cleanup error.','Trace original subprocess.run stdout/stderr and return code; command semantics unchanged.'],'retained_directories':kept,'commands':commands,'tests':result.testsRun,'errors':len(result.errors),'failures':len(result.failures),'skipped':len(result.skipped),'exit_code':0 if result.wasSuccessful() else 1,'started_at':started,'duration_seconds':round(time.monotonic()-t0,3)}
        (LOG/'python-diagnostic-replay.receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(receipt,ensure_ascii=False,indent=2));print(text);sys.exit(receipt['exit_code'])
    stream=io.StringIO();result=unittest.TextTestRunner(stream=stream,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Supplemental));text=stream.getvalue()
    (LOG/'supplemental-python.stderr.log').write_text(text,encoding='utf-8');(LOG/'supplemental-python.observations.json').write_text(json.dumps(notes,ensure_ascii=False,indent=2),encoding='utf-8')
    suite=ET.Element('testsuite',name='supplemental-python',tests=str(result.testsRun),failures=str(len(result.failures)),errors=str(len(result.errors)),skipped=str(len(result.skipped)))
    for name in unittest.defaultTestLoader.getTestCaseNames(Supplemental):
        c=ET.SubElement(suite,'testcase',classname='Supplemental',name=name)
        for typ,items in [('failure',result.failures),('error',result.errors),('skipped',result.skipped)]:
            for obj,detail in items:
                if obj._testMethodName==name:ET.SubElement(c,typ).text=detail
    ET.SubElement(suite,'system-err').text=text;ET.ElementTree(suite).write(LOG/'supplemental-python.junit.xml',encoding='utf-8',xml_declaration=True)
    receipt={'tag':'supplemental-python','argv':sys.orig_argv,'cwd':os.getcwd(),'started_at':started,'duration_seconds':round(time.monotonic()-t0,3),'exit_code':0 if result.wasSuccessful() else 1,'tests':result.testsRun,'errors':len(result.errors),'failures':len(result.failures),'skipped':len(result.skipped),'notes':['All data synthetic. No SSH, network, real SDK, model or actual OS signal.','Defect-prefixed tests assert residual defect existence.']};(LOG/'supplemental-python.receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8');print(text);print(json.dumps(receipt,ensure_ascii=False,indent=2));sys.exit(receipt['exit_code'])
