from __future__ import annotations
import base64,datetime,hashlib,json,pathlib,subprocess
ROOT=pathlib.Path(__file__).resolve().parent;OUT=ROOT/'s1-reference';OUT.mkdir(exist_ok=True)
REF='6c1b48d2962ec6a48d5a553e312dfcc1f94e2e7a';REPO='getpaseo/paseo';records=[]
paths=['packages/cli/package.json','packages/client/package.json','public-docs/cli.md','public-docs/configuration.md','public-docs/codex.md','public-docs/supported-providers.md','public-docs/security.md','packages/cli/src/commands/daemon/start.ts','packages/cli/src/commands/daemon/config.ts']
for rel in paths:
 args=['gh','api',f'repos/{REPO}/contents/{rel}?ref={REF}'];p=subprocess.run(args,capture_output=True,timeout=25);r={'path':rel,'argv':args,'exit_code':p.returncode,'ref':REF}
 if p.returncode==0:
  obj=json.loads(p.stdout);b=base64.b64decode(obj['content']);target=OUT/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
  actual=hashlib.sha1(f'blob {len(b)}\0'.encode()+b).hexdigest();assert actual==obj['sha'];r.update({'blob_sha1':actual,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'url':f'https://github.com/{REPO}/blob/{REF}/{rel}'})
 else:r['error']=p.stderr.decode('utf-8',errors='replace')
 records.append(r);print(json.dumps(r,ensure_ascii=False),flush=True)
(OUT/'SOURCES.json').write_text(json.dumps({'repo':REPO,'ref':REF,'retrieved_at':datetime.datetime.now().astimezone().isoformat(),'files':records},ensure_ascii=False,indent=2),encoding='utf-8')
p=subprocess.run(['gh','api',f'repos/{REPO}/releases/latest'],capture_output=True,timeout=25)
if p.returncode==0:
 obj=json.loads(p.stdout);summary={k:obj[k] for k in ['tag_name','name','published_at','html_url','prerelease']};(OUT/'LATEST_RELEASE.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(summary,ensure_ascii=False))
