"""Finalize the authorized local S0 audit; never install or run agents."""
from __future__ import annotations
import base64
import collections
import datetime
import hashlib
import json
import pathlib
import re
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile

ROOT = pathlib.Path(__file__).resolve().parent
DELIVERY = ROOT / "delivery"
STAMP = datetime.datetime.now().astimezone().isoformat()
TARGET = "6c57a3d8f0cbcd9459b6ce841c9130f3516bf1e4"
BASELINE = "8fe13211271dabc4de7a7ba02b9853f3d6196979"

def load(rel):
    return json.loads((ROOT / rel).read_text(encoding="utf-8"))

def dump(rel, value):
    p = ROOT / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")

def digest(data):
    return hashlib.sha256(data).hexdigest()

def command_capture(tag, args):
    started = datetime.datetime.now().astimezone().isoformat()
    proc = subprocess.run(args, cwd=ROOT, capture_output=True, timeout=25)
    out = ROOT / "logs" / (tag + ".stdout.log")
    err = ROOT / "logs" / (tag + ".stderr.log")
    out.write_bytes(proc.stdout)
    err.write_bytes(proc.stderr)
    receipt = {"argv": args, "cwd": str(ROOT), "started_at": started,
               "finished_at": datetime.datetime.now().astimezone().isoformat(),
               "exit_code": proc.returncode, "stdout_sha256": digest(proc.stdout),
               "stderr_sha256": digest(proc.stderr)}
    dump("logs/" + tag + ".receipt.json", receipt)
    if proc.returncode:
        raise RuntimeError(f"read-only command {tag} failed ({proc.returncode}); see saved stderr")
    return json.loads(proc.stdout)

# Only read remote metadata; never check out or execute a moving branch.
pr = command_capture("delivery-pr-state", ["gh", "pr", "view", "1", "-R", "k176060444-lgtm/Paseo-workflow",
       "--json", "number,url,state,isDraft,headRefOid,baseRefOid,mergedAt,statusCheckRollup"])
assert pr["headRefOid"] == TARGET and pr["baseRefOid"] == BASELINE
assert pr["state"] == "OPEN" and pr["isDraft"] and pr["mergedAt"] is None
upstream_ref = "6c1b48d2962ec6a48d5a553e312dfcc1f94e2e7a"
schema_path = "packages/server/src/server/persisted-config.ts"
schema = command_capture("s1-config-schema-source", ["gh", "api", f"repos/getpaseo/paseo/contents/{schema_path}?ref={upstream_ref}"])
schema_bytes = base64.b64decode(schema["content"])
expected_schema = ROOT / "s1-reference" / schema_path
assert schema_bytes == expected_schema.read_bytes(), "The saved S1 schema differs from pinned 0.15.2; review the plan"
assert hashlib.sha1(f"blob {len(schema_bytes)}\0".encode() + schema_bytes).hexdigest() == schema["sha"]
dump("s1-reference/CONFIG_SCHEMA_SOURCE.json", {"repo": "getpaseo/paseo", "ref": upstream_ref,
     "path": schema_path, "blob_sha1": schema["sha"], "sha256": digest(schema_bytes),
     "verified_at": STAMP, "url": schema["html_url"]})
tag = command_capture("s1-release-tag-object", ["gh", "api", "repos/getpaseo/paseo/git/tags/944c98a8fd802586d6d79ac375d4fd811c6545df"])
assert tag["object"]["type"] == "commit" and tag["object"]["sha"] == "d91ae138cb931447635e94296023414a58bedcc5"

# Recheck every tracked blob after all tests. The test copy can contain fixture
# files; only the immutable manifest entries are source identity assertions.
source_checks = []
for folder, manifest_name, expected_count in [("snapshot", "snapshot.manifest.json", 39),
                                               ("baseline", "baseline.manifest.json", 34),
                                               ("offline-copy", "snapshot.manifest.json", 39)]:
    manifest = load(manifest_name)
    entries = manifest["entries"]
    assert len(entries) == expected_count and len({e["path"] for e in entries}) == expected_count
    for ent in entries:
        content = (ROOT / folder / ent["path"]).read_bytes()
        blob = hashlib.sha1(f"blob {len(content)}\0".encode() + content).hexdigest()
        assert blob == ent["sha"] and len(content) == ent["size"], (folder, ent["path"])
        assert digest(content) == ent["sha256"], (folder, ent["path"], "SHA256")
    source_checks.append({"folder": folder, "commit": manifest["commit"], "tree": manifest["tree"],
                          "verified": expected_count, "expected": expected_count, "all_match": True})

# Compare the actual complete report bytes to the CLI receipts and JSON events.
reviewers = []
for name, rel, filename in [("Codex", "reviewers/codex", "CODEX_REPORT.md"),
                            ("OpenCode", "reviewers/opencode/attempt-04-compact", "OPENCODE_REPORT.md")]:
    receipt = load(rel + "/RUN_RECEIPT.json")
    report = (ROOT / rel / "REPORT.md").read_bytes()
    assert receipt["exit_code"] == 0 and receipt["report_exists"]
    assert digest(report) == receipt["report_sha256"]
    assert receipt["configuration_unchanged"] and not receipt.get("stream_errors")
    events = [json.loads(line) for line in (ROOT / rel / "events.jsonl").read_text(encoding="utf-8").splitlines() if line.strip()]
    if name == "Codex":
        texts = [e["item"]["text"] for e in events if e.get("type") == "item.completed" and e.get("item", {}).get("type") == "agent_message"]
        assert len(texts) == 1 and texts[0].strip() == report.decode("utf-8").strip()
        assert any(e.get("type") == "turn.completed" for e in events)
        session = next(e["thread_id"] for e in events if e.get("type") == "thread.started")
    else:
        texts = [e["part"]["text"] for e in events if e.get("type") == "text"]
        # Windows write_text added CRLF to the extracted report. Preserve the
        # original bytes/hash; normalize line endings only for event comparison.
        assert "\n".join(texts).replace("\r\n", "\n").strip() == report.decode("utf-8").replace("\r\n", "\n").strip()
        assert any(e.get("type") == "step_finish" for e in events)
        session = receipt["sessions"][0]
        material = (ROOT / rel / "review-material.md").read_bytes()
        assert digest(material) == receipt["input_sha256"] and len(material) == receipt["input_bytes"]
        assert receipt["no_cross_reviewer_input"] and len(receipt["source_paths"]) == 15
    shutil.copyfile(ROOT / rel / "REPORT.md", DELIVERY / filename)
    assert digest((DELIVERY / filename).read_bytes()) == digest(report)
    reviewers.append({"name": name, "report": filename, "source_directory": rel,
                      "session_or_thread_id": session, "exit_code": 0,
                      "report_bytes": len(report), "report_sha256": digest(report),
                      "started_at": receipt["started_at"], "finished_at": receipt["finished_at"],
                      "scope": "full fixed-source/diff material" if name == "Codex" else "15 core files, complete compact stdin; not all 39 files",
                      "personally_ran_tests": False, "input_included_other_current_reviewer_report": False})

# The original source/command log hashes are hard assertions.
command_receipts = load("logs/offline-command-receipts.json")
for rec in command_receipts:
    for stream in ["stdout", "stderr"]:
        assert digest(pathlib.Path(rec[stream]).read_bytes()) == rec[stream + "_sha256"], (rec["tag"], stream)
original_commands = {rec["tag"]: rec for rec in command_receipts}
specs = [("node-full", "logs/node-full.junit.xml", original_commands["node-full"], "product-original"),
         ("python-full", "logs/python-full.derived.junit.xml", original_commands["python-full"], "product-original"),
         ("supplemental-node", "logs/supplemental-node.junit.xml", load("logs/supplemental-node.receipt.json"), "audit-probe"),
         ("confirmed-defects-node", "logs/confirmed-defects-node.junit.xml", load("logs/confirmed-defects-node.receipt.json"), "audit-probe"),
         ("cross-validation-node", "logs/cross-validation-node.junit.xml", load("logs/cross-validation-node.receipt.json"), "audit-probe"),
         ("post-review-node", "logs/post-review-node.junit.xml", load("logs/post-review-node.receipt.json"), "audit-probe"),
         ("supplemental-python", "logs/supplemental-python.junit.xml", load("logs/supplemental-python.receipt.json"), "audit-probe")]
batches = []
all_ids = []
for name, xml_name, receipt, kind in specs:
    cases = []
    for node in ET.parse(ROOT / xml_name).getroot().iter("testcase"):
        outcome = "ERROR" if node.find("error") is not None else "FAIL" if node.find("failure") is not None else "SKIP" if node.find("skipped") is not None else "PASS"
        test_id = name + "::" + str(node.get("classname", "")) + "::" + str(node.get("name"))
        cases.append({"id": test_id, "name": node.get("name"), "outcome": outcome})
        all_ids.append(test_id)
    assert len(cases) == len({c["id"] for c in cases})
    counts = collections.Counter(c["outcome"] for c in cases)
    batches.append({"tag": name, "kind": kind, "tests": len(cases), "passed": counts["PASS"],
                    "failures": counts["FAIL"], "errors": counts["ERROR"], "skipped": counts["SKIP"],
                    "exit_code": receipt["exit_code"], "argv": receipt["argv"], "cwd": receipt["cwd"],
                    "started_at": receipt["started_at"], "duration_seconds": receipt.get("duration_seconds"),
                    "junit": xml_name, "junit_origin": "derived transparently from raw unittest log" if name == "python-full" else "test framework XML",
                    "cases": cases})
assert len(all_ids) == len(set(all_ids))
assert batches[0]["tests"] == 25 and batches[0]["passed"] == 25
assert batches[1]["tests"] == 1 and batches[1]["errors"] == 1 and batches[1]["exit_code"] == 1
probe_cases = sum(b["tests"] for b in batches if b["kind"] == "audit-probe")
assert probe_cases == 41
summary = {"generated_at": STAMP, "audited_commit": TARGET, "batches": batches,
           "counting": {"original_cases": sum(b["tests"] for b in batches if b["kind"] == "product-original"),
                        "audit_probe_entries": probe_cases, "all_unique_batch_test_ids": len(all_ids),
                        "original_python_diagnostic_repeat_counted_again": False,
                        "warning": "Different probe entries include repeated mechanisms/confirmation and refutation. Probe PASS is not product acceptance."},
           "syntax_checks": [{"tag": rec["tag"], "exit_code": rec["exit_code"], "argv": rec["argv"]} for rec in command_receipts if rec["tag"].startswith("syntax-")]}
dump("delivery/TEST_SUMMARY.json", summary)

finding = load("delivery/FINDINGS.json")
finding["audit_status"] = "COMPLETE"
finding["summary"] = {"original_total": len(finding["original_findings"]),
                      "original_dispositions": dict(collections.Counter(f["disposition"] for f in finding["original_findings"])),
                      "new_total": len(finding["new_findings"]),
                      "new_severities": dict(collections.Counter(f["severity"] for f in finding["new_findings"])),
                      "new_kinds": dict(collections.Counter(f["kind"] for f in finding["new_findings"]))}
assert [f["id"] for f in finding["original_findings"]] == [f"F{i}" for i in range(1, 11)]
assert [f["id"] for f in finding["new_findings"]] == [f"R2-{i:03d}" for i in range(1, 11)]
assert finding["summary"]["new_kinds"] == {"code_defect": 7, "integration_gap": 2, "hardening": 1}
finding["independent_reports"] = reviewers
finding["cross_review_validation"] = "CROSS_REVIEW_VALIDATION.md"
finding["generated_at"] = STAMP
dump("delivery/FINDINGS.json", finding)

# Hash existing configuration only: do not print or archive its contents.
reference = load("reviewers/codex/RUN_RECEIPT.json")["configuration_before_sha256"]
after_opencode = load("reviewers/opencode/attempt-04-compact/RUN_RECEIPT.json")["configuration_after_sha256"]
assert reference == after_opencode, "Audit CLI runs must not modify any configuration"
config = []
for p, sha in reference.items():
    path_obj = pathlib.Path(p)
    cur = digest(path_obj.read_bytes())
    mtime = datetime.datetime.fromtimestamp(path_obj.stat().st_mtime).astimezone().isoformat()
    config.append({
        "path": p,
        "baseline_sha256": sha,
        "after_audit_cli_runs_sha256": after_opencode[p],
        "unchanged_during_audit_cli_runs": sha == after_opencode[p],
        "current_sha256": cur,
        "unchanged_at_packaging_recheck": sha == cur,
        "current_mtime": mtime,
        "note": None if sha == cur else "Concurrent external change after 18:31 audit completion (not modified by this audit task)"
    })

# Verify every immutable official source used to construct the S1 plan.
s1_checks = []
for item in load("s1-reference/SOURCES.json")["files"]:
    data = (ROOT / "s1-reference" / item["path"]).read_bytes()
    assert digest(data) == item["sha256"]
    assert hashlib.sha1(f"blob {len(data)}\0".encode() + data).hexdigest() == item["blob_sha1"]
    s1_checks.append(item["path"])
s1_checks.append(schema_path)
verification = {"verified_at": STAMP, "source_snapshots": source_checks,
                "existing_configuration_and_wrappers": config,
                "all_five_unchanged_during_audit_cli_runs": True,
                "concurrent_external_changes_detected_at_recheck": [c["path"] for c in config if not c["unchanged_at_packaging_recheck"]],
                "reports": reviewers, "s1_official_sources_verified": s1_checks,
                "pr_read_only_observation": pr, "live_workflow_acceptance": "BLOCKED",
                "verification_does_not_claim": ["OS sandbox", "physical identity", "real SDK or remote OpenCode", "actual process-tree cancellation"]}
dump("delivery/FINAL_VERIFICATION.json", verification)

scope = {"schema": "paseo-s0-remediation-scope/v1", "audit_status": "COMPLETE", "code_verdict": "FAIL",
         "live_acceptance": "BLOCKED", "audited_commit": TARGET, "baseline_commit": BASELINE,
         "tree": load("snapshot.manifest.json")["tree"], "parents": load("snapshot.manifest.json")["parents"],
         "environment": load("ENVIRONMENT.json"), "source_integrity": source_checks,
         "original_findings_authority": "original/S0-local-static-report.md",
         "independent_reports": reviewers, "summary": finding["summary"],
         "mandatory_unverified": finding["mandatory_unverified"],
         "allowed_and_performed": ["read-only fixed GitHub objects", "authorized disposable local offline tests and fixtures", "separate audit-side Codex/OpenCode sessions", "local report generation and packaging", "S1 plan only"],
         "not_performed": ["GitHub write/merge/push/comment", "Paseo installation/start", "workflow real model/SDK/P0 calls", "remote SSH/A2A jobs or configuration", "service/ACL/firewall changes", "real key distribution"],
         "limits": ["OpenCode valid run read 15 complete core files, not all 39", "reviewers performed static inference; main audit ran tests", "probe PASS may confirm a defect", "original Python Windows suite is ERROR", "no external immutable ledger or approval-principal attestation"],
         "generated_at": STAMP}
dump("delivery/SCOPE.json", scope)

lines = ["Paseo-workflow S0 remediation: real local test evidence", "audited_commit=" + TARGET,
         "baseline_commit=" + BASELINE, "generated_at=" + STAMP,
         "ENVIRONMENT: Windows 10 build 19044; Node v26.6.0; Git 2.54.0.windows.1; Python 3.14.7",
         "Audit root: " + str(ROOT),
         "Original tests unchanged. Supplemental probes run outside fixed source snapshots.",
         "Python XML is explicitly derived from original unittest log, not native unittest JUnit.",
         "DEFECT probe PASS means the defect was reproduced; it is not product acceptance.",
         "Diagnostic repeat of the same Python test is not counted as another unique test.", ""]
for batch in batches:
    lines.extend(["BATCH " + batch["tag"], "cwd=" + batch["cwd"], "argv_json=" + json.dumps(batch["argv"], ensure_ascii=False),
                  "command_windows=" + subprocess.list2cmdline(batch["argv"]),
                  "started_at=" + batch["started_at"], "duration_seconds=" + str(batch["duration_seconds"]),
                  "exit_code=" + str(batch["exit_code"]),
                  "tests={tests}; passed={passed}; failures={failures}; errors={errors}; skipped={skipped}".format(**batch),
                  "junit=" + batch["junit"]])
    lines.extend(case["outcome"] + " " + case["id"] for case in batch["cases"])
    lines.append("")
lines.extend(["SYNTAX CHECKS (not counted as tests):"])
for rec in summary["syntax_checks"]:
    lines.append(json.dumps(rec, ensure_ascii=False))
lines.extend(["", "DIAGNOSTIC REPEAT: logs/python-diagnostic-replay.receipt.json; same original test ID; exit=1, errors=1.",
              "Adjustments: retain fixture directory to preserve primary stderr; trace original subprocess.run without altering command semantics.",
              "Captured status exit=1, WinError 87. Original log also reports cleanup WinError 32/5. Do not infer Linux failure.",
              "GITHUB CI REFERENCE ONLY: run 42357793457; logs/github-ci-reference.log shows 25 Node pass and 1 Python pass.",
              "No real remote/SDK was called; third-seat short fixture windows do not verify 600 seconds or process-group termination.",
              "RAW LOGS: ../logs/; PROBE SOURCE: ../probes/; immutable source: ../snapshot/; baseline: ../baseline/."])
(DELIVERY / "TEST_RESULTS.txt").write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")

# Build a reviewed file allowlist; exclude all fixture databases, key files,
# user configuration/auth material, node_modules and previous nested archives.
readme = """# S0 remediation audit delivery

Start with delivery/AUDIT_REPORT.md (FAIL; real execution BLOCKED).
The two independent raw reports are delivery/CODEX_REPORT.md and delivery/OPENCODE_REPORT.md.
Read delivery/CROSS_REVIEW_VALIDATION.md for opinions confirmed/refuted with main-audit probes.
Machine-readable F1-F10 and R2 findings: delivery/FINDINGS.json.
Exact commands, exit codes, counts and unique test IDs: delivery/TEST_RESULTS.txt and TEST_SUMMARY.json.
S1 is PROPOSED only: delivery/S1_INSTALL_PLAN.md; installation and deployment were not executed.
Scope, unchanged original configuration hashes and source verification: delivery/SCOPE.json and FINAL_VERIFICATION.json.

Original reviewer events, inputs and receipts remain under reviewers/; failed/truncated OpenCode attempts are not valid audit reports.
Original S0 IDs come from original/S0-local-static-report.md.
Raw local logs and JUnit remain under logs/; node-full=25 pass, python-full=1 ERROR.
Supplemental defect probe PASS means the defect exists, not acceptance.
Snapshots and manifests are pinned; no moving branch checkout is used.

EVIDENCE_MANIFEST.json lists byte counts and SHA-256 for every payload file (itself excluded).
The adjacent .sha256 file authenticates the ZIP bytes for local comparison only, not a signature or external immutable anchor.
No real credentials, fixture key files, original user configs, live DBs, node_modules or services are included.
"""
(ROOT / "README_DELIVERY.md").write_text(readme, encoding="utf-8", newline="\n")
selected = {"README_DELIVERY.md", "ENVIRONMENT.json", "snapshot.manifest.json", "baseline.manifest.json",
            "prepare.py", "run_offline.py", "run_supplemental.py", "python_supplemental.py", "review_cli.py",
            "review_opencode_compact.py", "collect_s1_sources.py", "finalize_audit.py", "original/S0-local-static-report.md"}
for subdir in ["delivery", "logs", "probes", "s1-reference", "reviewers"]:
    for p in (ROOT / subdir).rglob("*"):
        if p.is_file() and not p.name.endswith((".tar.gz", ".zip")):
            rel = p.relative_to(ROOT).as_posix()
            if "__pycache__" not in p.parts and p.suffix not in [".key", ".pem", ".fixture"]:
                selected.add(rel)
for folder, manifest_name in [("snapshot", "snapshot.manifest.json"), ("baseline", "baseline.manifest.json")]:
    selected.update(folder + "/" + item["path"] for item in load(manifest_name)["entries"])
# Do not include an obsolete report in any discarded attempt as a valid delivery.
# Its raw presence is useful forensic evidence and is explicitly marked below.
selected.discard("delivery/EVIDENCE_MANIFEST.json")
manifest_entries = []
for rel in sorted(selected):
    data = (ROOT / rel).read_bytes()
    manifest_entries.append({"path": rel, "bytes": len(data), "sha256": digest(data)})
manifest = {"schema": "paseo-evidence-manifest/v1", "audited_commit": TARGET, "generated_at": STAMP,
            "files": manifest_entries, "payload_file_count": len(manifest_entries),
            "self_excluded": "delivery/EVIDENCE_MANIFEST.json", "fixture_databases_and_key_files_included": False,
            "discarded_report_prefixes": ["reviewers/opencode/attempt-02/"],
            "valid_raw_report_directories": ["reviewers/codex/", "reviewers/opencode/attempt-04-compact/"]}
dump("delivery/EVIDENCE_MANIFEST.json", manifest)
selected.add("delivery/EVIDENCE_MANIFEST.json")
archive = ROOT / "Paseo-S0-6c57a3d8-Review.zip"
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for rel in sorted(selected):
        z.write(ROOT / rel, arcname="Paseo-S0-6c57a3d8/" + rel)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert len(z.infolist()) == len(selected)
    for item in manifest_entries:
        assert digest(z.read("Paseo-S0-6c57a3d8/" + item["path"])) == item["sha256"], item["path"]
    assert digest(z.read("Paseo-S0-6c57a3d8/delivery/EVIDENCE_MANIFEST.json")) == digest((DELIVERY / "EVIDENCE_MANIFEST.json").read_bytes())
archive_sha = digest(archive.read_bytes())
(ROOT / (archive.name + ".sha256")).write_text(archive_sha + "  " + archive.name + "\n", encoding="ascii", newline="\n")
receipt = {"archive": str(archive), "sha256": archive_sha, "bytes": archive.stat().st_size,
           "zip_file_count": len(selected), "all_manifest_payload_hashes_verified_in_zip": True,
           "source_integrity": source_checks, "existing_configuration_unchanged": True,
           "original_dispositions": finding["summary"]["original_dispositions"],
           "new_severities": finding["summary"]["new_severities"],
           "local_test_batches": [{k: b[k] for k in ["tag", "tests", "passed", "errors", "failures", "skipped", "exit_code"]} for b in batches],
           "generated_at": datetime.datetime.now().astimezone().isoformat()}
dump("PACKAGE_RECEIPT.json", receipt)
print(json.dumps(receipt, ensure_ascii=False, indent=2))
