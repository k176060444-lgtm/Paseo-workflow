import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHmac} from 'node:crypto';
import {Store} from '../snapshot/src/store.mjs';
import {WorkflowController} from '../snapshot/src/controller.mjs';
import {SshP0Adapter} from '../snapshot/src/p0.mjs';
import {PaseoAgentRuntime} from '../snapshot/src/agents.mjs';
import {ROLE_PERMISSIONS,MAX_A,MAX_B,canonical,sha256,parseAgentOutput} from '../snapshot/src/policy.mjs';
import {execArgv} from '../snapshot/src/git.mjs';
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const TMP=path.join(ROOT,'probe-state');fs.mkdirSync(TMP,{recursive:true});
const SHA='a'.repeat(40);let serial=0;
const note=(id,body)=>console.log('[AUDIT] '+JSON.stringify({id,...body}));
function fixture(stage='A_REVIEW'){
 const dir=fs.mkdtempSync(path.join(TMP,`case-${++serial}-`));const store=new Store(dir);
 const frozen={policy:{maxA:MAX_A,maxB:MAX_B,permissions:ROLE_PERMISSIONS},project:{repo:dir},roles:{},souls:{blind_a:{text:'A'},blind_b:{text:'B'},blind_c:{text:'C'}}};frozen.digest=sha256(frozen);
 const task={id:'TASK1234',stage,status:'READY',frozen,history:[],aRound:1,bRound:1,currentSha:SHA,baseSha:SHA,worktree:dir,taskSpec:'Offline approved fixture specification',taskSpecSha:'b'.repeat(64),bFindings:[],inflight:null};
 store.init(task);let calls=0;
 const runtime={execute:async x=>{calls++;return {role:x.role,phase:x.phase,agentId:`fixture-${calls}`,verdict:'PASS',summary:'Fixture only',findings:[]};}};
 const gitOps={head:async()=>SHA,assertUnchanged:async()=>{}};
 const c=new WorkflowController({store,runtime,p0:null,gitOps});
 return {dir,store,task,c,runtime,gitOps,get calls(){return calls;},close(){store.close();}};
}
function p0fixture(){const f=fixture('P0_INITIAL');f.nodes=['seat-a','seat-b','seat-c'].map((id,i)=>{
 const key=path.join(f.dir,`synthetic-${id}.hmac`);fs.writeFileSync(key,Buffer.alloc(40,65+i));
 return {id,physicalId:`fixture-physical-${i}`,sshAlias:`fixture-alias-${i}`,hmacKeyPath:key,enabled:true,role:['blind_a','blind_b','blind_c'][i],harness:'opencode',model:'opencode/fixture',runner:'/fixture/runner.py',config:'/fixture/config.json'};});
 f.trace=[];f.adapter=new SshP0Adapter(f.nodes,{pollMs:0,extraThirdMs:0,deadlineMs:1000,sleep:async()=>{}});f.c.p0=f.adapter;
 return f;
}
function signed(n,jobId){const body={jobId,nodeId:n.id,physicalId:n.physicalId,commit:SHA,model:n.model,harness:n.harness,exitCode:0,clean:true,stdoutSha256:'c'.repeat(64),verdict:'PASS',summary:'Synthetic review',findings:[]};
 return {body,mac:createHmac('sha256',fs.readFileSync(n.hmacKeyPath)).update(canonical(body)).digest('hex')};}
function wire(f,{absent=null,pending=null,lostAck=null,cancel='CANCELLED'}={}){
 f.adapter.ssh=async(n,a,p)=>{f.trace.push(`${n.id}:${a}`);
  if(a==='probe'){if(n.id===absent)throw Error('synthetic offline preflight');return {status:'READY',nodeId:n.id,physicalId:n.physicalId};}
  if(a==='submit'){if(n.id===lostAck)throw Error('synthetic lost ACK');return {status:'ACCEPTED',jobId:p.jobId};}
  if(a==='status')return n.id===pending?{status:'RUNNING',jobId:p.jobId}:{status:'FINISHED',jobId:p.jobId,result:signed(n,p.jobId)};
  if(a==='cancel')return {status:cancel,jobId:p.jobId,nodeId:n.id};throw Error('unexpected action');};
}
async function review(f){return f.adapter.review({task:f.task,commit:SHA,taskSpec:'Offline only',store:f.store,cycle:'independent-1'});}
// These switches exist only inside this isolated test process, with all external adapters replaced.
process.env.P1_LIVE_ALLOWED='YES';process.env.P1_HOST_ISOLATION_ATTESTED='YES';

test('R-F1: PASS plus BLOCKER returns A_WORKER rather than A_TEST in the real step()',async()=>{
 const f=fixture();try{let i=0;f.runtime.execute=async x=>({role:x.role,agentId:`r-${++i}`,verdict:'PASS',summary:'synthetic contradictory result',findings:x.role==='spec_reviewer'?['BLOCKER: fixture defect']:[]});
 await f.c.step(f.task);const t=f.store.get(f.task.id);assert.equal(t.stage,'A_WORKER');note('R-F1',{stage:t.stage,findings:t.aFindings});}finally{f.close();}});

test('R-F1-parser: contradictory native result is rejected and legacy verdicts normalize',()=>{
 const result=(verdict,findings=[])=>JSON.stringify({verdict,findings,summary:'Fixture'});
 assert.throws(()=>parseAgentOutput(result('PASS',['BLOCKER: fixture']),'spec_reviewer'),/inconsistent PASS/);
 assert.equal(parseAgentOutput(result('APPROVE'),'spec_reviewer').verdict,'PASS');assert.equal(parseAgentOutput(result('REQUEST_CHANGES'),'quality_reviewer').verdict,'FAIL');});

for(const absent of ['seat-a','seat-b','seat-c'])test(`R-F2-pair-${absent}: other two distinct fixture identities form quorum without dispatching absent seat`,async()=>{
 const f=p0fixture();try{wire(f,{absent});const r=await review(f);assert(r.passed);assert.equal(r.reports.length,2);assert.equal(new Set(r.reports.map(x=>x.physicalId)).size,2);assert(!f.trace.includes(`${absent}:submit`));f.store.verify(f.task.id);
 note(`R-F2-pair-${absent}`,{reports:r.reports.map(x=>x.nodeId),skipped:r.missing,trace:f.trace,physical_identity:'SIMULATED_ONLY'});}finally{f.close();}});

test('R-F2-cancel-uncertain: ambiguous third-seat cancellation blocks and retains acknowledged dispatch',async()=>{
 const f=p0fixture();try{wire(f,{pending:'seat-c',cancel:'CANCEL_UNCERTAIN'});await assert.rejects(()=>review(f),/cancel uncertain/);const ds=f.store.dispatches(f.task.id);assert.equal(ds.filter(x=>x.state==='ACKNOWLEDGED').length,1);assert.equal(ds.filter(x=>x.state==='TERMINAL').length,2);f.store.verify(f.task.id);note('R-F2-cancel-uncertain',{dispatch_states:ds.map(x=>x.state),trace:f.trace});}finally{f.close();}});

test('R-F2-cancelled: known third cancellation is stored with separate receipt',async()=>{
 const f=p0fixture();try{wire(f,{pending:'seat-c'});const r=await review(f);assert(r.passed);assert.equal(r.cancelled.length,1);assert(f.store.dispatches(f.task.id).every(x=>x.state==='TERMINAL'));f.store.verify(f.task.id);note('R-F2-cancelled',{cancelled:r.cancelled,trace:f.trace});}finally{f.close();}});

test('R-F2-lost-ACK: controller becomes NEEDS_RECONCILIATION and a second run does not redispatch',async()=>{
 const f=p0fixture();try{wire(f,{lostAck:'seat-c'});await assert.rejects(()=>f.c.run(f.task.id),/lost ACK/);const first=f.trace.length;const t=f.store.get(f.task.id);assert.equal(t.status,'NEEDS_RECONCILIATION');await assert.rejects(()=>f.c.run(f.task.id),/reconcile before dispatch/);assert.equal(f.trace.length,first);assert.equal(f.store.dispatches(f.task.id).filter(x=>x.state==='DISPATCH_INTENT').length,1);note('R-F2-lost-ACK',{stage:t.stage,status:t.status,dispatch_states:f.store.dispatches(f.task.id).map(x=>x.state),no_second_dispatch:true});}finally{f.close();}});

test('R-F3: duplicated synthetic key bytes at different paths cause zero SSH adapter calls',async()=>{
 const f=p0fixture();try{fs.copyFileSync(f.nodes[0].hmacKeyPath,f.nodes[1].hmacKeyPath);wire(f);await assert.rejects(()=>review(f),/duplicate P0 attestation key content/);assert.equal(f.trace.length,0);note('R-F3',{adapter_calls:0,duplicate_bytes_rejected:true});}finally{f.close();}});

test('R-F4: actual runtime passes a numeric one-hour timeout to the SDK-shaped stub',async()=>{
 const f=fixture();try{let timeout;const r=new PaseoAgentRuntime('fixture://no-network');r.client={agents:{create:async()=>({id:'fake-sdk-id',waitForFinish:async arg=>{timeout=arg;return{status:'idle',lastMessage:JSON.stringify({verdict:'PASS',summary:'stub only',findings:[],taskSpec:'A complete fixture plan with tests.'})};}})}};
 f.task.frozen.roles.planner={harness:'codex',model:'codex/fixture'};f.task.frozen.souls.planner={text:'Frozen fixture Soul',sha256:'a'.repeat(64)};
 await r.execute({task:f.task,role:'planner',phase:'R-F4',cwd:f.dir,prompt:'Fixture',store:f.store});assert.equal(timeout,3600000);assert.equal(typeof timeout,'number');note('R-F4',{timeout,type:typeof timeout,real_sdk:'NOT_VERIFIED'});}finally{f.close();}});

test('R-F5: Markdown followed by a final JSON remains incompatible with JSON.parse-only contract',()=>{
 const raw='# Review report\n\nEvidence and verdict.\n'+JSON.stringify({verdict:'APPROVE',summary:'fixture',findings:[]});assert.throws(()=>parseAgentOutput(raw,'spec_reviewer'),/non-JSON/);note('R-F5',{markdown_plus_json:'REJECTED',legacy_json_aliases:'ACCEPTED',soul_migration:'NOT_COMPLETED'});});

for(const action of ['init','intent','ack','terminal'])test(`R-F7-atomic-${action}: event-write fault rolls back its associated SQLite row mutation`,()=>{
 const f=fixture();try{const oldEvent=f.store.event.bind(f.store);let expected;
 if(action==='init')expected='CREATED';if(action==='intent')expected='DISPATCH_INTENT';if(action==='ack')expected='DISPATCH_ACK';if(action==='terminal')expected='DISPATCH_TERMINAL';
 if(['ack','terminal'].includes(action))f.store.recordIntent(f.task.id,'fixture','dispatch-x');if(action==='terminal')f.store.recordAck('dispatch-x','fake-agent');
 const before=f.store.dispatches(f.task.id);const n=f.store.verify(f.task.id).events;
 f.store.event=(id,type,payload)=>{if(type===expected)throw Error('injected event write failure');return oldEvent(id,type,payload);};
 if(action==='init')assert.throws(()=>f.store.init({...f.task,id:'TASK5678'}),/injected/);
 if(action==='intent')assert.throws(()=>f.store.recordIntent(f.task.id,'fixture','dispatch-x'),/injected/);
 if(action==='ack')assert.throws(()=>f.store.recordAck('dispatch-x','fake-agent'),/injected/);
 if(action==='terminal')assert.throws(()=>f.store.recordTerminal('dispatch-x'),/injected/);
 f.store.event=oldEvent;assert.deepEqual(f.store.dispatches(f.task.id),before);if(action==='init')assert.equal(f.store.get('TASK5678'),null);assert.equal(f.store.verify(f.task.id).events,n);note(`R-F7-atomic-${action}`,{row_rollback:true,event_count_unchanged:true});}finally{f.close();}});

test('R-F7-ledger: event alteration and dispatch deletion are detected',()=>{
 const f=fixture();try{f.store.recordIntent(f.task.id,'fixture','dispatch-x');f.store.db.prepare('DELETE FROM dispatches WHERE id=?').run('dispatch-x');assert.throws(()=>f.store.verify(f.task.id),/dispatch ledger mismatch/);note('R-F7-ledger',{deleted_dispatch:'DETECTED'});}finally{f.close();}
 const g=fixture();try{g.store.db.prepare('UPDATE events SET payload=? WHERE task_id=?').run('{}',g.task.id);assert.throws(()=>g.store.verify(g.task.id),/event ledger hash mismatch/);note('R-F7-event',{altered_event:'DETECTED'});}finally{g.close();}});

test('R-F7-evidence: altered file, deleted manifest entry and missing evidence are rejected',()=>{
 const f=fixture();try{const a=f.store.artifact(f.task.id,'registered.json',{result:'fixture'});const original=fs.readFileSync(a.path);fs.writeFileSync(a.path,'corrupt');assert.throws(()=>f.store.verify(f.task.id),/artifact hash mismatch/);fs.writeFileSync(a.path,original);f.store.verify(f.task.id);f.store.db.prepare('DELETE FROM artifacts WHERE task_id=?').run(f.task.id);assert.throws(()=>f.store.verify(f.task.id),/artifact manifest mismatch/);note('R-F7-evidence',{alteration:'DETECTED',deleted_registration:'DETECTED'});}finally{f.close();}});

test('DEFECT-R8-01: failing preflight reanchors a tampered task row, then recovery retains the lowered budget',async()=>{
 const f=fixture('B_ENTER');try{f.task.bRound=9;f.task.p0Initial={commit:SHA,passed:false,findings:['fixture'],reports:[]};f.store.save(f.task,'FIXTURE_BEFORE_TAMPER');
 const changed=f.store.get(f.task.id);changed.bRound=0;f.store.db.prepare('UPDATE tasks SET data=? WHERE id=?').run(canonical(changed),f.task.id);
 assert.throws(()=>f.store.verify(f.task.id),/state differs/);await assert.rejects(()=>f.c.run(f.task.id),/state differs/);
 const after=f.store.get(f.task.id);assert.equal(after.stage,'BLOCKED');assert.equal(after.bRound,0);
 const checkAfter=f.store.verify(f.task.id); // Defect assertion: invalid state is now accepted by verifier.
 f.c.authorizeRecovery({id:f.task.id,actor:'fixture-human',receipt:'Offline synthetic recovery approval only; not user authorization.',expectedSha:SHA});
 const recovered=f.store.get(f.task.id);assert.equal(recovered.bRound,0);assert.equal(recovered.stage,'B_ENTER');await f.c.step(recovered);assert.equal(f.store.get(f.task.id).bRound,1);
 note('DEFECT-R8-01',{before_budget:9,tampered_budget:0,preflight_stage:after.stage,verify_after_preflight:checkAfter,recovery_budget:f.store.get(f.task.id).bRound,model_calls:f.calls,meaning:'PROBE PASS MEANS DEFECT REPRODUCED'});}finally{f.close();}});

test('R-F8: a genuine budget violation persists BLOCKED, recovery does not reset the exhausted budget',async()=>{
 const f=fixture('A_WORKER');try{f.task.aRound=MAX_A+1;f.store.save(f.task,'FIXTURE_BUDGET_VIOLATION');await assert.rejects(()=>f.c.run(f.task.id),/round budget exceeded/);const t=f.store.get(f.task.id);assert.equal(t.stage,'BLOCKED');assert.equal(f.calls,0);f.c.authorizeRecovery({id:t.id,actor:'fixture-human',receipt:'Offline explicit synthetic recovery receipt.',expectedSha:SHA});assert.equal(f.store.get(t.id).aRound,MAX_A+1);await assert.rejects(()=>f.c.run(t.id),/round budget exceeded/);note('R-F8',{status:f.store.get(t.id).status,budget_preserved:MAX_A+1,model_calls:f.calls});}finally{f.close();}});

test('R-F8: recovery refuses an acknowledged unresolved operation',()=>{
 const f=fixture('BLOCKED');try{f.task.status='BLOCKED';f.store.save(f.task,'FIXTURE_BLOCK');f.store.recordIntent(f.task.id,'fixture','dispatch-x');f.store.recordAck('dispatch-x','fixture-agent');assert.throws(()=>f.c.authorizeRecovery({id:f.task.id,actor:'fixture-human',receipt:'Offline synthetic recovery receipt only.',expectedSha:SHA}),/outstanding dispatch/);note('R-F8-outstanding',{recovery:'REJECTED'});}finally{f.close();}});

test('R-F9: a real local child process cannot see an unrelated synthetic gateway token',async()=>{
 const old=process.env.PASEO_AUDIT_FAKE_TOKEN;process.env.PASEO_AUDIT_FAKE_TOKEN='synthetic-value-not-a-credential';try{const r=await execArgv(process.execPath,['-e','process.stdout.write(String(Object.hasOwn(process.env,"PASEO_AUDIT_FAKE_TOKEN")))']);assert.equal(r.code,0);assert.equal(r.stdout,'false');note('R-F9',{unrelated_sentinel_visible:false,actual_local_child:true});}finally{if(old===undefined)delete process.env.PASEO_AUDIT_FAKE_TOKEN;else process.env.PASEO_AUDIT_FAKE_TOKEN=old;}});

for(const cmd of ['status','verify'])test(`R-F10-${cmd}: nonexistent state is not created by CLI query`,async()=>{
 const dir=path.join(TMP,`query-missing-${cmd}-${process.pid}`);assert(!fs.existsSync(dir));const r=await execArgv(process.execPath,[path.join(ROOT,'snapshot/src/cli.mjs'),cmd,'--id','TASK1234','--state',dir]);assert.equal(r.code,1);assert(!fs.existsSync(dir));note(`R-F10-${cmd}`,{exit_code:r.code,state_created:false,stderr:r.stderr.trim()});});

test('R-F10-existing: observe actual WAL side files during read-only Store verification',()=>{
 const f=fixture();const id=f.task.id,dir=f.dir;f.close();const before=fs.readdirSync(dir);const r=new Store(dir,{readOnly:true});try{r.verify(id);const during=fs.readdirSync(dir);note('R-F10-existing',{before,during,added:during.filter(n=>!before.includes(n)),readonly_query_observation:true});}finally{r.close();}});
