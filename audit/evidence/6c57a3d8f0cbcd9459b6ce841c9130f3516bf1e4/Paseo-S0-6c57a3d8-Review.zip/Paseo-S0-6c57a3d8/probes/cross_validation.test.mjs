import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';import {createHmac} from 'node:crypto';
import {Store} from '../snapshot/src/store.mjs';import {WorkflowController} from '../snapshot/src/controller.mjs';import {SshP0Adapter} from '../snapshot/src/p0.mjs';import {canonical,sha256} from '../snapshot/src/policy.mjs';import {execArgv} from '../snapshot/src/git.mjs';
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),TMP=path.join(ROOT,'crosscheck-state'),SHA='a'.repeat(40);fs.mkdirSync(TMP,{recursive:true});
const note=(id,data)=>console.log('[AUDIT] '+JSON.stringify({id,...data}));
function fixture(stage='A_REVIEW'){const dir=fs.mkdtempSync(path.join(TMP,'case-')),store=new Store(dir),task={id:'TASK1234',stage,status:stage==='NEEDS_RECONCILIATION'?'NEEDS_RECONCILIATION':'READY',frozen:{digest:'fixture'},history:[],aRound:1,bRound:1,currentSha:SHA,inflight:null};store.init(task);return {dir,store,task};}

test('X-F2: third-seat FINISHED-at-cancel with a signed FAIL is included and blocks',async()=>{
 const f=fixture();try{f.task.frozen.souls={blind_a:{text:'fixture'}};const nodes=['a','b','c'].map((id,i)=>{const key=path.join(f.dir,id+'.fixture');fs.writeFileSync(key,Buffer.alloc(40,65+i));return {id,enabled:true,physicalId:'physical-'+id,sshAlias:'alias-'+id,harness:'opencode',model:'opencode/fixture',hmacKeyPath:key};});
 const p0=new SshP0Adapter(nodes,{pollMs:0,extraThirdMs:0});
 function signed(n,j,fail=false){const body={jobId:j,nodeId:n.id,physicalId:n.physicalId,commit:SHA,harness:n.harness,model:n.model,exitCode:0,clean:true,stdoutSha256:'b'.repeat(64),verdict:fail?'FAIL':'PASS',summary:'fixture',findings:fail?['HIGH: late conflict']:[]};return {body,mac:createHmac('sha256',fs.readFileSync(n.hmacKeyPath)).update(canonical(body)).digest('hex')};}
 p0.ssh=async(n,a,s)=>{if(a==='probe')return {status:'READY',nodeId:n.id,physicalId:n.physicalId};if(a==='submit')return {status:'ACCEPTED',jobId:s.jobId};if(a==='status')return n.id==='c'?{status:'RUNNING',jobId:s.jobId}:{status:'FINISHED',jobId:s.jobId,result:signed(n,s.jobId)};if(a==='cancel')return {status:'FINISHED',jobId:s.jobId,result:signed(n,s.jobId,true)};throw Error('unexpected')};
 const result=await p0.review({task:f.task,commit:SHA,taskSpec:'fixture',store:f.store,cycle:'crosscheck'});assert.equal(result.passed,false);assert.equal(result.reports.length,3);assert.equal(result.dispute,true);assert.deepEqual(result.findings,['HIGH: late conflict']);note('X-F2',{passed:result.passed,reports:result.reports.length,dispute:result.dispute,findings:result.findings,claim_late_fail_discarded:'REFUTED'});
 }finally{f.store.close();}});

test('X-F8: terminal NEEDS_RECONCILIATION stage is not overwritten on missing preflight flags',async()=>{
 const f=fixture('NEEDS_RECONCILIATION');try{const before=f.store.verify(f.task.id);const c=new WorkflowController({store:f.store,runtime:null,p0:null});const old=process.env.P1_LIVE_ALLOWED;delete process.env.P1_LIVE_ALLOWED;try{await assert.rejects(()=>c.run(f.task.id),/live dispatch disabled/);}finally{if(old!==undefined)process.env.P1_LIVE_ALLOWED=old;}
 const after=f.store.get(f.task.id);assert.equal(after.stage,'NEEDS_RECONCILIATION');assert.equal(after.status,'NEEDS_RECONCILIATION');assert.deepEqual(f.store.verify(f.task.id),before);note('X-F8',{stage:after.stage,status:after.status,event_count_unchanged:true,blanket_terminal_stage_rewrite_claim:'REFUTED'});
 }finally{f.store.close();}});

test('X-F7: empty events table is rejected',()=>{const f=fixture();try{f.store.db.prepare('DELETE FROM events WHERE task_id=?').run(f.task.id);assert.throws(()=>f.store.verify(f.task.id),/missing audit events/);note('X-F7',{empty_events:'REJECTED'});}finally{f.store.close();}});

test('DEFECT-X-F10: real status CLI against a closed existing WAL DB creates persistent companion files',async()=>{
 const f=fixture();const {dir,task}=f;f.store.close();const before=fs.readdirSync(dir);const bytes=fs.readFileSync(path.join(dir,'workflow.sqlite'));const result=await execArgv(process.execPath,[path.join(ROOT,'snapshot/src/cli.mjs'),'status','--id',task.id,'--state',dir]);assert.equal(result.code,0);const after=fs.readdirSync(dir);assert(after.includes('workflow.sqlite-wal'));assert(after.includes('workflow.sqlite-shm'));assert.equal(sha256(fs.readFileSync(path.join(dir,'workflow.sqlite')).toString('hex')),sha256(bytes.toString('hex')));note('DEFECT-X-F10',{exit_code:result.code,before,after,added:after.filter(n=>!before.includes(n)),main_db_bytes_unchanged:true,meaning:'PASS demonstrates filesystem query side effect, not data mutation'});
});
