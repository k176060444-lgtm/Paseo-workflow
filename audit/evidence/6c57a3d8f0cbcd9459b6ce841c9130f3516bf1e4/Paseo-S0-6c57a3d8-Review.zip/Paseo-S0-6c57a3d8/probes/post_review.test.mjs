import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {Store} from '../snapshot/src/store.mjs';
import {WorkflowController} from '../snapshot/src/controller.mjs';
import {PaseoAgentRuntime} from '../snapshot/src/agents.mjs';
import {MAX_A,MAX_B,ROLE_PERMISSIONS,sha256} from '../snapshot/src/policy.mjs';
import {must,commitWorktree} from '../snapshot/src/git.mjs';
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const TMP=path.join(ROOT,'post-review-state');fs.mkdirSync(TMP,{recursive:true});
const SHA='a'.repeat(40);
const note=(id,data)=>console.log('[AUDIT] '+JSON.stringify({id,...data,meaning:'PASS = OBSERVATION/DEFECT REPRODUCED; no real model, credential or remote'}));
function fixture(stage='A_REVIEW'){
 const dir=fs.mkdtempSync(path.join(TMP,'case-')),store=new Store(dir);
 const frozen={policy:{maxA:MAX_A,maxB:MAX_B,permissions:ROLE_PERMISSIONS},project:{repo:dir},roles:{spec_reviewer:{harness:'opencode',model:'OFFLINE_FIXTURE_ONLY'},quality_reviewer:{harness:'opencode',model:'OFFLINE_FIXTURE_ONLY'}},souls:{spec_reviewer:{text:'fixture'},quality_reviewer:{text:'fixture'}}};frozen.digest=sha256(frozen);
 const task={id:'TASK1234',stage,status:'READY',frozen,history:[],aRound:1,bRound:0,currentSha:SHA,baseSha:SHA,taskSpec:'Offline fixture',taskSpecSha:'b'.repeat(64),worktree:dir,inflight:null,bFindings:[]};store.init(task);return {dir,store,task};
}
test('POST-R2-008: early BLOCKED with null currentSha cannot be recovered via the public CLI',async()=>{
 const f=fixture('BLOCKED');try{
  f.task.status='BLOCKED';f.task.currentSha=null;f.task.baseSha=null;f.task.taskSpecSha=null;f.store.save(f.task,'SYNTHETIC_EARLY_PREFLIGHT_BLOCK');
  const receipt=path.join(f.dir,'receipt.fixture.txt');fs.writeFileSync(receipt,'Offline synthetic human receipt, no actual authorization implied.');
  const args=['../snapshot/src/cli.mjs','recover','--state',f.dir,'--id',f.task.id,'--actor','fixture-human','--receipt',receipt];
  const {execArgv}=await import('../snapshot/src/git.mjs');
  const noSha=await execArgv(process.execPath,[path.join(ROOT,'snapshot/src/cli.mjs'),...args.slice(1)],{cwd:ROOT});
  assert.equal(noSha.code,1);assert.match(noSha.stderr,/required --sha/);
  const withSha=await execArgv(process.execPath,[path.join(ROOT,'snapshot/src/cli.mjs'),...args.slice(1),'--sha',SHA],{cwd:ROOT});
  assert.equal(withSha.code,1);assert.match(withSha.stderr,/not the approved recovery basis/);
  assert.equal(f.store.get(f.task.id).status,'BLOCKED');assert.equal(f.store.get(f.task.id).currentSha,null);
  note('POST-R2-008',{no_sha_exit:noSha.code,no_sha_stderr:noSha.stderr.trim(),sha_exit:withSha.code,sha_stderr:withSha.stderr.trim(),currentSha:null,scope:'public CLI; API direct null was not used as a recovery bypass'});
 }finally{f.store.close();}
});
async function makeRepo(){
 const dir=fs.mkdtempSync(path.join(TMP,'git-fixture-'));const g=(...args)=>must('git',args,{cwd:dir});
 await g('init','-q');await g('config','core.autocrlf','false');const hooks=path.join(dir,'empty-hooks');fs.mkdirSync(hooks);await g('config','core.hooksPath',hooks);
 fs.writeFileSync(path.join(dir,'.env'),'SYNTHETIC_AUDIT_VALUE=fixture-original\n');await g('add','--','.env');
 await g('-c','user.name=Offline Audit Fixture','-c','user.email=offline-fixture@localhost','commit','-q','-m','Disposable offline fixture, no remote');return {dir,g};
}
test('POST-R2-009a: porcelain rename source path is truncated and a sensitive-name rename is committed',async()=>{
 const f=await makeRepo();await f.g('mv','.env','ordinary.txt');
 const raw=await must('git',['status','--porcelain','-z','--untracked-files=all'],{cwd:f.dir});
 assert.equal(raw,'R  ordinary.txt\0.env\0');const parsed=raw.split('\0').filter(Boolean).map(e=>e.slice(3));assert.deepEqual(parsed,['ordinary.txt','v']);
 const commit=await commitWorktree(f.dir,'OFFLINE_RENAME_PROBE');assert.match(commit,/^[0-9a-f]{40}$/);assert.equal(await f.g('show','HEAD:ordinary.txt'),'SYNTHETIC_AUDIT_VALUE=fixture-original');
 note('POST-R2-009a',{porcelain:raw,parsed_paths:parsed,commit_created:true,head:commit,synthetic_data_only:true,repository:f.dir,no_remote_configured:!(await f.g('remote')).length});
});
test('POST-R2-009b: trim() removes the first status space and tracked .env modification is committed',async()=>{
 const f=await makeRepo();fs.writeFileSync(path.join(f.dir,'.env'),'SYNTHETIC_AUDIT_VALUE=fixture-modified\n');
 const raw=await must('git',['status','--porcelain','-z','--untracked-files=all'],{cwd:f.dir});assert.equal(raw,'M .env\0');assert.equal(raw.slice(3),'env\0');
 const commit=await commitWorktree(f.dir,'OFFLINE_TRACKED_ENV_PROBE');assert.equal(await f.g('show','HEAD:.env'),'SYNTHETIC_AUDIT_VALUE=fixture-modified');
 note('POST-R2-009b',{trimmed_porcelain:raw,checked_first_path:raw.split('\0')[0].slice(3),commit_created:true,head:commit,synthetic_data_only:true,repository:f.dir});
});
test('POST-R2-010: successful reviewer result is not preserved when its peer fails, using the real adapter with a fake SDK',async()=>{
 const f=fixture();let sdkCreates=0;const runtime=new PaseoAgentRuntime('OFFLINE_NOT_CONNECTED');
 runtime.client={agents:{create:async({config})=>{
  const n=++sdkCreates;
  return {id:`fixture-agent-${n}`,waitForFinish:async()=>{
   if(n===2)throw Error('Synthetic quality wait failure');
   return {status:'idle',lastMessage:JSON.stringify({verdict:'PASS',summary:'SYNTHETIC_SUCCESS_MUST_BE_PRESERVED',findings:[]})};
  }};
 }}};
 const c=new WorkflowController({store:f.store,runtime,p0:null,gitOps:{assertUnchanged:async()=>{}}});
 try{
  await assert.rejects(()=>c.invokePair(f.task,'audit-pair',SHA),/Reviewer call failed/);
  const dispatches=f.store.dispatches(f.task.id);assert.equal(dispatches.length,2);assert.equal(dispatches.filter(d=>d.state==='TERMINAL').length,1);
  const rows=f.store.db.prepare('SELECT * FROM artifacts WHERE task_id=?').all(f.task.id);assert.equal(rows.length,0);assert.equal(f.store.get(f.task.id).history.length,0);
  const last=f.store.db.prepare('SELECT type,payload FROM events WHERE task_id=? ORDER BY seq DESC LIMIT 1').get(f.task.id);assert.equal(last.type,'REVIEW_PAIR_UNCERTAIN');assert(!last.payload.includes('SYNTHETIC_SUCCESS_MUST_BE_PRESERVED'));
  const verified=f.store.verify(f.task.id);
  note('POST-R2-010',{sdk_is_fake:true,real_PaseoAgentRuntime_execute:true,sdk_creates:sdkCreates,terminal_dispatches:1,acknowledged_dispatches:1,artifact_rows:rows.length,history_rows:0,event:last.type,event_payload:JSON.parse(last.payload),verify_events:verified.events,scope:'controller evidence; external SDK transcript persistence was not checked'});
 }finally{f.store.close();}
});
