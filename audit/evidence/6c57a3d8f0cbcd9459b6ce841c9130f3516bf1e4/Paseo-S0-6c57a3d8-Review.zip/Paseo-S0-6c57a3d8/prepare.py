from __future__ import annotations
import concurrent.futures
import datetime
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import platform
import subprocess
import sys
import tarfile

ROOT = Path(__file__).resolve().parent
REPO = 'k176060444-lgtm/Paseo-workflow'
TARGET = '6c57a3d8f0cbcd9459b6ce841c9130f3516bf1e4'
BASELINE = '8fe13211271dabc4de7a7ba02b9853f3d6196979'
ORIGINAL = '375b2ac191ce7beafdcee8664c45c9287de4388f'
LOGS = ROOT / 'logs'
LOGS.mkdir(exist_ok=True)

def gh(endpoint: str, raw: bool = False) -> bytes:
    args = ['gh', 'api', endpoint]
    if raw:
        args += ['-H', 'Accept: application/vnd.github.raw+json']
    proc = subprocess.run(args, capture_output=True, timeout=55)
    if proc.returncode:
        raise RuntimeError(f'{args!r}: exit={proc.returncode}: {proc.stderr.decode("utf-8", errors="replace")}')
    return proc.stdout

def git_blob(data: bytes) -> str:
    return hashlib.sha1(b'blob ' + str(len(data)).encode('ascii') + b'\0' + data).hexdigest()

def snapshot(label: str, sha: str) -> dict:
    out = ROOT / label
    if out.is_dir():
        manifest = json.loads((ROOT / f'{label}.manifest.json').read_text(encoding='utf-8'))
        assert manifest['commit'] == sha
        for e in manifest['entries']:
            data = (out / e['path']).read_bytes()
            assert git_blob(data) == e['sha'] and len(data) == e['size']
        return {'label': label, 'sha': sha, 'tree': manifest['tree'], 'parents': manifest['parents'], 'verified': len(manifest['entries'])}
    out.mkdir(exist_ok=False)
    commit = json.loads(gh(f'repos/{REPO}/commits/{sha}'))
    tree = json.loads(gh(f'repos/{REPO}/git/trees/{sha}?recursive=1'))
    assert commit['sha'] == sha and not tree.get('truncated')
    entries = [e for e in tree['tree'] if e['type'] == 'blob']
    archive = gh(f'repos/{REPO}/tarball/{sha}')
    (LOGS / f'{label}.tar.gz').write_bytes(archive)
    extracted = {}
    with tarfile.open(fileobj=io.BytesIO(archive), mode='r:gz') as tf:
        for m in tf.getmembers():
            if not m.isfile():
                if not m.isdir():
                    raise RuntimeError(f'Non-regular archive entry: {m.name}')
                continue
            parts = PurePosixPath(m.name).parts[1:]
            if not parts or '..' in parts:
                raise RuntimeError('Unsafe archive path')
            rel = '/'.join(parts)
            data = tf.extractfile(m).read()
            p = out.joinpath(*parts)
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(data)
            extracted[rel] = data
    verified = []
    for e in entries:
        data = extracted[e['path']]
        assert git_blob(data) == e['sha'] and len(data) == e['size'], e['path']
        verified.append({'path': e['path'], 'sha': e['sha'], 'size': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'mode': e['mode']})
    assert len(extracted) == len(entries)
    manifest = {'repo': REPO, 'commit': sha, 'tree': commit['commit']['tree']['sha'], 'parents': [p['sha'] for p in commit['parents']], 'entries': verified}
    (ROOT / f'{label}.manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    (LOGS / f'{label}.commit.json').write_text(json.dumps(commit, ensure_ascii=False, indent=2), encoding='utf-8')
    return {'label': label, 'sha': sha, 'tree': manifest['tree'], 'parents': manifest['parents'], 'verified': len(verified)}

if __name__ == '__main__':
    env = {'timestamp': datetime.datetime.now().astimezone().isoformat(), 'host': platform.node(), 'platform': platform.platform(), 'python': sys.version, 'python_executable': sys.executable, 'cwd': os.getcwd(), 'audit_root': str(ROOT), 'forbidden_live_flags_present': [k for k in os.environ if k.startswith('P1_')], 'reviewer_authorization': 'User permitted audit-side Codex/OpenCode model sessions only; workflow live execution, remote nodes and deployment prohibited.'}
    results = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        for result in pool.map(lambda x: snapshot(*x), [('snapshot', TARGET), ('baseline', BASELINE)]):
            results.append(result)
    original = ROOT / 'original'
    original.mkdir(exist_ok=True)
    prefix = f'audit/evidence/{BASELINE}/'
    for name in ['S0-local-static-report.md', 'Paseo-S0-8fe132-evidence.zip']:
        if (original / name).is_file():
            continue
        endpoint = f'repos/{REPO}/contents/{prefix}{name}?ref={ORIGINAL}'
        if name.endswith('.zip'):
            import base64
            content = json.loads(gh(endpoint))
            data = base64.b64decode(content['content'])
            assert git_blob(data) == content['sha']
        else:
            data = gh(endpoint, raw=True)
        (original / name).write_bytes(data)
    env['snapshots'] = results
    env['original_audit_source_commit'] = ORIGINAL
    (ROOT / 'ENVIRONMENT.json').write_text(json.dumps(env, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(env, ensure_ascii=False, indent=2))
