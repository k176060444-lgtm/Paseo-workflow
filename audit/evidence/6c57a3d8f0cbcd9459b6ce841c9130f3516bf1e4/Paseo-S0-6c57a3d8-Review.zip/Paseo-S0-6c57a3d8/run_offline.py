from __future__ import annotations
import datetime, hashlib, json, os, pathlib, platform, re, shutil, subprocess, sys, time
import xml.etree.ElementTree as ET
ROOT=pathlib.Path(__file__).resolve().parent
LOG=ROOT/'logs'; LOG.mkdir(exist_ok=True)
WORK=ROOT/'offline-copy'
if not WORK.exists(): shutil.copytree(ROOT/'snapshot',WORK)
TMP=ROOT/'offline-temp'; TMP.mkdir(exist_ok=True)
env=os.environ.copy()
for k in tuple(env):
    if k.startswith('P1_'): del env[k]
for k in ['TEMP','TMP','TMPDIR']: env[k]=str(TMP)
env['PYTHONDONTWRITEBYTECODE']='1'
node=shutil.which('node'); git=shutil.which('git')
receipts=[]
def run(tag,args,timeout=55):
    started=datetime.datetime.now().astimezone().isoformat(); begin=time.monotonic()
    try:
        p=subprocess.run(args,cwd=WORK,env=env,capture_output=True,timeout=timeout)
        code=p.returncode; out=p.stdout; err=p.stderr
    except subprocess.TimeoutExpired as e:
        code=124;out=e.stdout or b'';err=(e.stderr or b'')+b'\nAUDIT RUNNER TIMEOUT\n'
    (LOG/(tag+'.stdout.log')).write_bytes(out);(LOG/(tag+'.stderr.log')).write_bytes(err)
    r={'tag':tag,'argv':args,'cwd':str(WORK),'started_at':started,'duration_seconds':round(time.monotonic()-begin,3),'exit_code':code,'stdout':str(LOG/(tag+'.stdout.log')),'stderr':str(LOG/(tag+'.stderr.log')),'stdout_sha256':hashlib.sha256(out).hexdigest(),'stderr_sha256':hashlib.sha256(err).hexdigest(),'temporary_files_root':str(TMP)}
    receipts.append(r);(LOG/'offline-command-receipts.json').write_text(json.dumps(receipts,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(r,ensure_ascii=False),flush=True)
    return code,out.decode('utf-8',errors='replace'),err.decode('utf-8',errors='replace')
versions={}
for tag,args in [('node-version',[node,'--version']),('git-version',[git,'--version']),('python-version',[sys.executable,'--version'])]:
    rc,o,e=run(tag,args);versions[tag]=o.strip() or e.strip()
for f in sorted((WORK/'src').glob('*.mjs')): run('syntax-'+f.stem,[node,'--check',str(f)])
tests=sorted((WORK/'tests').glob('*.test.mjs'))
node_xml=LOG/'node-full.junit.xml'
code,out,err=run('node-full',[node,'--test','--test-reporter=spec','--test-reporter-destination=stdout','--test-reporter=junit','--test-reporter-destination='+str(node_xml),*[str(f) for f in tests]],timeout=55)
node_cases=[];node_counts={}
if node_xml.exists():
    tree=ET.parse(node_xml)
    for case in tree.findall('.//testcase'):
        node_cases.append({'name':case.attrib['name'],'classname':case.attrib.get('classname'),'failed':case.find('failure') is not None,'error':case.find('error') is not None,'skipped':case.find('skipped') is not None})
    names=[(x['classname'],x['name']) for x in node_cases];assert len(names)==len(set(names))
    node_counts={'tests':len(node_cases),'failures':sum(x['failed'] for x in node_cases),'errors':sum(x['error'] for x in node_cases),'skipped':sum(x['skipped'] for x in node_cases)}
    node_counts['passed']=node_counts['tests']-sum(node_counts[k] for k in ['failures','errors','skipped'])
code2,pout,perr=run('python-full',[sys.executable,'-B','-m','unittest','discover','-s','remote/tests','-v'],timeout=55)
match=re.search(r'Ran (\d+) tests? in',pout+'\n'+perr)
py_log=(pout+'\n'+perr).replace('\r\n','\n')
py_names=re.findall(r'^([a-zA-Z0-9_]+ \([^\n]+\)) \.\.\. (ok|FAIL|ERROR|skipped[^\n]*)$',py_log,re.M)
py_counts={'tests':int(match.group(1)) if match else None,'passed':sum(x[1]=='ok' for x in py_names),'failures':sum(x[1]=='FAIL' for x in py_names),'errors':sum(x[1]=='ERROR' for x in py_names),'skipped':sum(x[1].startswith('skipped') for x in py_names)}
# This XML is explicitly a transformation of the preserved unittest stdout/stderr.
suite=ET.Element('testsuite',name='unittest raw-log conversion',tests=str(py_counts['tests']),failures=str(py_counts['failures']),errors=str(py_counts['errors']),skipped=str(py_counts['skipped']))
for name,result in py_names:
    case=ET.SubElement(suite,'testcase',name=name)
    if result!='ok':ET.SubElement(case,'failure' if result=='FAIL' else 'error' if result=='ERROR' else 'skipped').text=perr
ET.SubElement(suite,'system-err').text=perr
ET.ElementTree(suite).write(LOG/'python-full.derived.junit.xml',encoding='utf-8',xml_declaration=True)
summary={'platform':platform.platform(),'versions':versions,'node':node_counts,'node_cases':node_cases,'python':py_counts,'python_cases':py_names,'node_exit_code':code,'python_exit_code':code2,'source_copy':str(WORK),'notes':['All P0 SSH calls in Node suites are local stubs.','Python case executes a local mock_native.py with synthetic key and disposable Git/SQLite state only.','No SDK dependency installation or live runtime is required.','Node JUnit is emitted by Node itself; Python XML is explicitly derived from actual unittest logs.']}
(LOG/'OFFLINE_RESULTS.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,indent=2))
sys.exit(0 if code==0 and code2==0 and node_counts.get('tests')==25 and py_counts['tests']==1 and py_counts['passed']==1 else 1)
