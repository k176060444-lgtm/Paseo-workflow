



# Paseo-workflow S0 整改独立复审报告（OpenCode 席）

**复审对象**：`k176060444-lgtm/Paseo-workflow`
**基线**：`8fe13211271dabc4de7a7ba02b9853f3d6196979`
**目标**：`6c57a3d8f0cbcd9459b6ce841c9130f3516bf1e4`（tree `31084b689af34414dafd4c5c3f136f96e6f29d43`，parent `79ca810…`）
**可见材料提交时间戳**：无（未提供 commit 时间）；本次复审仅基于编排者下发的固定 blob 材料。
**总判定：S0 INCONCLUSIVE（不通过）；部署、真实模型调用、远端 P0、S1 进入一律 BLOCKED。**
**PASS+BLOCKER 结论：不成立。** 本席不给 PASS；F2/F3/F6 三条 BLOCKER 在可见材料内仍无解除证据，另有 1 条由材料自身暴露的新 HIGH（N1）与 3 条 MEDIUM。

---

## 0. 证据边界（先声明，避免把推断当事实）

1. 本席**没有执行任何命令**：未运行 `npm test`、`npm run check`、Python unittest、任何探针、任何真实 SDK/SSH/远端节点/模型；未修改任何文件；未读取任何用户配置或认证文件。
2. 下发给本席的材料**在第 560 行处被截断**。收到的内容为：原始 S0 报告全文、目标 Commit 的 `.github/workflows/offline-tests.yml`、`.gitignore`、`README.md`、`config/*.example.*`、`docs/ARCHITECTURE.md`、`docs/AUDIT_HANDOFF.md`、`docs/PASEO_LOCAL_TEST_PLAN.md`、`docs/S0_REMEDIATION_20261107.md`、`docs/SECURITY.md`（至第 22 行）。**目标 Commit 的 `src/controller.mjs`、`src/policy.mjs`、`src/p0.mjs`、`src/store.mjs`、`src/git.mjs`、`src/agents.mjs`、`src/cli.mjs`、`remote/p0_runner.py`、`tests/`、`remote/tests/` 均未出现在本席材料中**；同样，所谓"完整官方离线 Node/Python 输出"的原始 receipts（stdout/stderr/exit code）也未出现在可见部分。
3. 因此本报告**不对目标 Commit 的源码作任何行号断言**，也不复述任何"MCP/HTTP/模型已跑通"之类未发生的事。凡需要目标源码或真实执行才能定论的项，一律 `NOT_VERIFIED`；凡目标文档自己承认未完成的合同项，判 `NOT_FIXED`（合同层）。文档与整改说明是待检数据，**不是 PASS 证据**。
4. 本席未看到、也不引用另一审计员（Codex 席）的任何结论。

---

## 1. F1–F10 判定表

| # | 子问题 | 判定 | 级别 | 依据（可见材料） | 事实 / 模拟 / 未验 |
|---|---|---|---|---|---|
| F1 | a. `PASS` + `BLOCKER/HIGH` findings 自相矛盾是否被拒 | NOT_VERIFIED | BLOCKER（遗留） | `docs/S0_REMEDIATION:9` 仅声明；目标 `src/controller.mjs`、`src/policy.mjs` 未在材料中 | 未验（需源码 + 反例执行） |
| F1 | b. 旧判决 `APPROVE/REQUEST_CHANGES` 兼容后的放行面 | NOT_VERIFIED（新增风险见 N5） | HIGH | 同上 | 未验 |
| F2 | a. 任意两席不同物理节点先成席、第三席后置 | NOT_VERIFIED | BLOCKER（遗留） | `S0_REMEDIATION:10`；`ARCHITECTURE:58` 仍是规则描述，非实现 | 未验 |
| F2 | b. 第三席预探测失败即可不派发（策略变更） | NOT_VERIFIED + 需用户确认（N6） | HIGH | `S0_REMEDIATION:10` 与 `README:12`、`ARCHITECTURE:58` 语义不一致 | 未验 |
| F2 | c. 取消 / ACK 对账闭环；丢 ACK 停线 | NOT_VERIFIED；真实取消覆盖 **BLOCKED** | BLOCKER（遗留） | `S0_REMEDIATION:10,23` 自承 `cancel` 用 Linux 进程组信号，可能覆盖不到 OpenCode 自启 daemon，`CANCEL_UNCERTAIN` 必须停线 | 未验 |
| F3 | a. 同内容不同路径 HMAC key 在派发前拒绝 | NOT_VERIFIED（并有设计冲突 N4） | BLOCKER（遗留） | `S0_REMEDIATION:11` 仅声明 | 未验 |
| F3 | b. 报告签名绑定 `physicalId` + SSH 别名不同 | NOT_VERIFIED | HIGH | `S0_REMEDIATION:11`、`ARCHITECTURE:56` | 未验 |
| F3 | c. 5bao/9bao 物理身份独立性 | **BLOCKED** | BLOCKER（遗留） | `S0_REMEDIATION:24`、`SECURITY:12` 自承签名不证明物理机器；`role-matrix.example:21-23` 的 `physicalId` 是人工配置字符串 | 未验（人工/硬件证据链缺失） |
| F4 | `waitForFinish` 超时参数类型与真实超时行为 | NOT_VERIFIED | HIGH（遗留） | `S0_REMEDIATION:12` 自承"真实 SDK/daemon 超时、断线仍 BLOCKED"；`ARCHITECTURE:48` 版本未装 | 未验 |
| F5 | a. 解析器兼容旧判决 | NOT_VERIFIED | HIGH | `S0_REMEDIATION:13` | 未验 |
| F5 | b. Soul ↔ V2.1 判决/交付物/派发契约映射 | **NOT_FIXED**（合同层） | HIGH | `S0_REMEDIATION:13` 自承"Soul 1.1.0 尚不能作为已批准 V2.1 新版本…完整 Markdown/JSON 法定交付物映射未完成" | 事实（目标文档自承） |
| F6 | a. Windows OS 级只读/网络/文件隔离 | **BLOCKED** | BLOCKER（遗留） | `SECURITY:9,10,22`、`S0_REMEDIATION:14,25` 均列为未验 | 未验 |
| F6 | b. TEST_ONLY 新增测试的授权范围、评审与归并进最终 Commit | **NOT_FIXED**（合同层） | BLOCKER（遗留） | `SECURITY:11` 明确"测试文件增量如何合入正式 Commit，仍应由本地审计判断"，无实现契约 | 事实（目标文档自承） |
| F6 | c. 子进程树 / Windows Job Object 终止 | **BLOCKED** | HIGH | `S0_REMEDIATION:18`、`SECURITY:22` | 未验 |
| F7 | a. tasks/dispatches/events/证据摘要事务绑定 | NOT_VERIFIED | HIGH | `S0_REMEDIATION:15` 仅声明 | 未验 |
| F7 | b. 事件链与证据文件内容摘要校验（含空事件） | NOT_VERIFIED | HIGH | 同上 | 未验 |
| F7 | c. 并发写窗口、统一互斥 | NOT_VERIFIED（Windows 侧有反向信号，见 N1） | HIGH | `S0_REMEDIATION:18` 声称共用任务锁；`SECURITY:16` 仍承认可被特权重写 | 未验 |
| F8 | a. 合规失败是否统一落 `BLOCKED` 而非抛错 | NOT_VERIFIED | HIGH | `S0_REMEDIATION:16` 仅声明 | 未验 |
| F8 | b. preflight 是否"先写后校验"或仍在 run 锁之前 | NOT_VERIFIED | HIGH | 同上；`src/controller.mjs` 未在材料中 | 未验 |
| F8 | c. 人工恢复边界（仅 BLOCKED、非 INFLIGHT、拒非 TERMINAL 派发） | NOT_VERIFIED | HIGH | `S0_REMEDIATION:16`；`ARCHITECTURE:64` | 未验 |
| F9 | a. 子进程环境白名单（Git/test/SSH） | NOT_VERIFIED | HIGH | `S0_REMEDIATION:17` | 未验 |
| F9 | b. 原始日志/证据的 Secret 边界、Windows ACL、远端日志权限 | NOT_VERIFIED；ACL 部分 **BLOCKED** | HIGH | `S0_REMEDIATION:17` 自承"Windows ACL、远端日志边界和密钥保存仍 BLOCKED" | 未验 |
| F10 | a. `status/verify` 只读副作用 | NOT_VERIFIED（+ 明确技术疑点 N1） | MEDIUM→**HIGH**（见 N1） | `S0_REMEDIATION:18`；材料外观测"Windows status 返回 1 后测试清理文件占用" | 未验 |
| F10 | b. 进程树 kill / 超时后上报 `UNKNOWN` | BLOCKED（kill）/ NOT_VERIFIED（UNKNOWN 上报） | MEDIUM | `S0_REMEDIATION:18` | 未验 |

**regression 判定**：未观察到 REGRESSION；但 N1、N5 提示修复面可能引入新的失败模式，需定向复测后才能排除。

---

## 2. 剩余 BLOCKER（不得以任何离线绿测解除）

- **B-1（F2）**：第三席取消/对账无确定 ACK 即停线的闭环，在真实 OpenCode 自启 daemon 场景下**无法证明零残留**；`S0_REMEDIATION:23` 自己写明 `CANCEL_UNCERTAIN` 必须停线 —— 这意味着真实环境下该路径的默认结果是"停线"，而不是"可放行"。性质：BLOCKED，需 Linux 实机进程组/僵尸进程观测。
- **B-2（F3）**：跨节点 HMAC key 复用检测与 `physicalId` 绑定最多是"控制域内的声明绑定"；**物理机器身份**必须由人工/硬件证据链（机器清单、SSH 主机指纹、跨机原始调用记录）建立。`SECURITY:12` 与 `S0_REMEDIATION:24` 均自承。性质：BLOCKED。
- **B-3（F6）**：Windows 10 LTSC 上的 OS 级只读、网络阻断、进程树终止、TEST_ONLY 写边界**全部未测**；`SECURITY:22` 仍将其列为 BLOCKER。CI 在 `ubuntu-latest` 上运行（`offline-tests.yml:8`），结构上不可能覆盖这一层。
- **B-4（F6-b / F5-b，合同层 NOT_FIXED）**：TEST_ONLY 新增测试如何评审并归并进"最终 Commit"，以及 Soul 判决/交付物与 V2.1 的法定映射，**在目标文档里仍是"待判断/未完成"**，即需求项未落地，不属"实现正确性未验"，而是"契约缺失"。
- **B-5（F1）**：PASS+严重级 findings 的阻断规则**没有任何可见实现证据**。这是"审查通过但带 BLOCKER"的最高风险面，必须看到目标 `policy.mjs`/`controller.mjs` 与反例用例输出才能解除。
- **B-6（运行闸门语义）**：`P1_LIVE_ALLOWED` / `P1_HOST_ISOLATION_ATTESTED` 是**人工操作员开关，不是隔离或认证证明**（`README:52`、`SECURITY:3`）。不得以"设 YES 后能跑通"作为 S0 通过证据；也不得把任何人工 env 审批当作身份/权限认证。

---

## 3. 事实 / 模拟 / 未验 三线分界

| 类别 | 内容 |
|---|---|
| **事实（材料内可直接确认）** | 目标文档自承项：F2 `cancel` 覆盖不足（`S0_REMEDIATION:23`）、F3 物理身份无证明（`:24`）、F5 Soul 未批准且映射未完成（`:13`）、F6 Windows/ACL/TEST_ONLY 归并 BLOCKED（`:14,17,25`）、F9 ACL BLOCKED（`:17`）、旧状态库不支持原地升级（`:26`）、env 开关非证书（`:27`）、Gate B 首轮计数未改且待用户确认（`:28`）；`SECURITY:9-12,20-22` 仍列 BLOCKER；CI 仅在 ubuntu + Node 22 运行（`offline-tests.yml:8,13`）；README 指向 `python3`（`README:31`）。 |
| **模拟（材料声称存在，但本席未见原始 receipts，不计为证据）** | 单测中的 fake Agent / fake P0 / 临时 SQLite / 临时 Git worktree（`S0_REMEDIATION:22`）；`waitForFinish` 调用参数断言（`:12`）。模拟**不能**解除 F2 进程组、F4 真实超时、F6 OS 隔离、F3 物理身份。 |
| **未验 / BLOCKED** | 真实 Paseo 0.15.2 daemon 与认证、Provider/model 实际身份与计费、Soul 注入、OpenCode JSONL 真实事件格式、5bao/9bao SSH 主机密钥与物理清单、600 秒第三席实测、SQLite 崩溃/断电/WAL、Windows ACL 与进程树、TEST_ONLY 新增测试归并、证据链抗篡改外部锚定。 |

---

## 4. 可见材料内的具体可验证问题（非风格挑刺）

**N1 — HIGH｜Windows `status` 返回 1 + 清理时文件占用，指向句柄/锁未释放**
观测（由编排者转述的官方输出，本席未见 stderr）：Windows 上 `status` 子命令 exit 1，随后测试清理阶段出现文件占用。
静态推断：这与 F10-a"只读打开现有 DB"直接冲突 —— 如果 `status/verify` 走 `node:sqlite` 打开数据库，即使 `readOnly`，在 WAL 模式下读者仍可能创建/持有 `-shm`、`-wal` 附属文件与文件句柄；若 `Store` 未显式 `close()`，Windows 上目录删除必失败（Linux 允许 unlink 已打开文件，故 **CI 的 ubuntu 覆盖不可能发现此缺陷**）。
影响：只读查询有副作用 + 状态目录泄漏；同时说明"只读"路径在目标 OS 上未被验收。
最小修复：`status/verify` 用只读连接并 `try/finally` 关闭；显式测试"打开→关闭→删除目录"在 Windows 成功；把该断言加入 CI 的 Windows job（新增 `windows-latest` matrix）。

**N2 — MEDIUM｜入口命令在目标 OS 上不可用，文档与整改单不一致**
`README:30-31` 与 `offline-tests.yml:18-19` 用 `python3`；基线审计中该命令在本机 **exit 127（command not found）**；而 `S0_REMEDIATION:32` 改用 `python`。同一仓库三处口径不一。
影响：S0 复现步骤在 Windows 上会直接失败，易被误读为"测试通过/环境问题"。
最小修复：README 给出 Windows/Linux 双写法（`py -3` / `python3`）并统一 CI 与整改单。

**N3 — MEDIUM｜"Node 25 成功、Python 1 ERROR"不是全绿，且 ERROR 的 stderr 未披露**
可见材料未包含 Python `ERROR` 的 traceback。`remote/p0_runner.py` 是 F2（cancel）、F8（对账）、F9（环境白名单/日志）的实现载体；其测试 ERROR 未被解释前，**这三项的代码路径一律视为未验证**。
禁止：把"1 ERROR 疑为环境问题"写成结论。需单独重跑并在报告中附完整 traceback 与归类（导入错误 / 断言失败 / 权限 / 平台）。

**N4 — MEDIUM｜"同内容不同路径 key 拒绝"与"不读取原始密钥"原则冲突**
`S0_REMEDIATION:11` 要求比较两侧 key 内容。要实现它，Controller 进程必须把两侧 key 字节读入内存；而原始整改方向要求"防止读取或记录原始密钥"。
风险：key 字节若进入异常消息、日志、SQLite 证据行或 `console`，即构成 F9 泄漏面；此外逐字节比较可被时序侧信道（低风险），且无法识别"同一随机源派生但内容不同"的两把 key。
最小修复：以摘要比较（如 `SHA-256(key)` 或 HMAC-based fingerprint）替代原始字节比对；比较用的 fingerprint **永不落盘、不入日志**；只记录 `keyFingerprintPrefix` 与节点 ID。

**N5 — MEDIUM｜旧判决兼容 × 严重级规则的组合矩阵未定义**
`S0_REMEDIATION:9` 同时引入"兼容 `APPROVE/REQUEST_CHANGES`"与"`BLOCKER/HIGH/P0/P1` 不得放行"。若 `APPROVE_WITH_COMMENTS` + 含 `HIGH` findings 的映射规则未显式定义，F1 可从新入口复现。
最小修复：对 `{PASS, FAIL, QUESTION, NEEDS_SPECIALIST, APPROVE, APPROVE_WITH_COMMENTS, REQUEST_CHANGES} × {BLOCKER, HIGH, P0, P1, MEDIUM, LOW, 无}` 做穷举表驱动测试，逐格断言期望阶段，断言的"期望"需用户确认而非开发者定义。

**N6 — MEDIUM｜"第三席预探测失败即可不派发"是业务规则变更**
`README:12`、`ARCHITECTURE:58` 的现行语义是"第三席在两份有效结果后最多再等 600 秒"；`S0_REMEDIATION:10` 引入前置预探测并可跳过派发。这改变了对"第三席是否必须尝试"的承诺，属需求变更，须用户确认，不能由整改单方面生效。

**N7 — LOW｜CI 供应链与权限面**
`offline-tests.yml:10,11` 使用浮动标签 `actions/checkout@v4`、`actions/setup-node@v4`；job 未声明 `permissions: contents: read`。非本次 S0 缺陷，但属可低成本收敛的面。

**N8 — MEDIUM｜合同项仍未闭环：Gate B 首轮计数**
`ARCHITECTURE:33` + `S0_REMEDIATION:28` 明确"无整改首次验证计为第 1 轮"仍**待用户确认**，且整改未改动。该项在用户书面确认前，Gate B 预算不可视为已定义。

---

## 5. 逐项复现方案（**均未执行**，仅静态分析后给出的最小待办）

> 以下步骤本席**没有运行**；它们是解除对应 NOT_VERIFIED 的最小充分条件，不应被读成"已跑通"。

- **F1**：以内存 stub 调目标 `WorkflowController.step`，输入 `{verdict:'PASS', findings:['BLOCKER: x']}`，断言阶段不变且写 `BLOCKED`；再跑 N5 的 7×7 矩阵。
- **F2**：stub 三节点，构造（i）前两席 ACCEPTED、第三席 submit 抛错；（ii）第三席 RUNNING 且超窗；（iii）第三席 cancel 无回执。断言（i）不因第三席失败而丢弃双席结果、（ii）不忽略迟到结果、（iii）落 `NEEDS_RECONCILIATION`/`BLOCKED` 而非 PASS。
- **F3**：两节点用不同路径、**相同字节** key，断言派发前拒绝；再用不同字节 key 但相同 `physicalId`，断言拒绝。物理身份仍标 BLOCKED。
- **F4**：需真实 `@getpaseo/client@0.15.2` + daemon；断言 `waitForFinish` 实参为 number 且真实到时断连可恢复。当前 BLOCKED。
- **F5**：目标解析器对 `APPROVE/REQUEST_CHANGES` 的返回；映射清单需用户批准后才可判 FIXED，当前合同层 NOT_FIXED。
- **F6**：Windows 受限账户下验证 TEST_ONLY 写入被拒、网络被断、子进程树被 Job Object 终止；TEST_ONLY 新增测试的评审归并流程需先由用户定义。当前 BLOCKED / NOT_FIXED。
- **F7**：在 SQLite 事务中注入"dispatches 写入后崩溃"，断言重启后 `verify` 报错；手工改动证据文件一字节，断言摘要校验失败；空事件表断言 `verify` 非零退出。
- **F8**：制造合规断言失败，断言落 `BLOCKED` 且 preflight 在锁内、在阶段错误处理之内；对存在非 TERMINAL 派发的任务调用 `recover`，断言被拒。
- **F9**：设置含 `AWS_SECRET_ACCESS_KEY`/`P1_*` 的父环境，断言子进程 stdio 与日志中不出现该值；Windows ACL 需另测。
- **F10**：对既有状态目录执行两次 `status`，断言目录 mtime/文件列表不变且无新增 `-wal/-shm`（Windows）；对超时子进程断言 `UNKNOWN` 上报与无残留进程。这也是 N1 的直接复测。

---

## 6. 结论与建议

1. **S0 不通过，保持停线。** 可见材料只能证明"整改意图与自承边界写清楚了"，不能证明任何 F1/F2/F3/F7/F8 的控制逻辑已在目标 Commit 上正确实现；F3 物理身份、F4 真实 SDK、F6 Windows 隔离与 TEST_ONLY 归并、F5 Soul 契约在目标文档中**被自己列为未完成或 BLOCKED**。
2. **不得以离线测试通过作为放行依据**：Node 25 pass 是事实但范围有限；Python 1 ERROR 未解释；Windows `status` exit 1 属实质性负面信号（N1）。
3. **不得以人工 env 开关或审批收据替代认证**：`P1_LIVE_ALLOWED`/`P1_HOST_ISOLATION_ATTESTED` 仅表达操作员意图。
4. **要解除本席的 NOT_VERIFIED，最小材料是**：目标 Commit 的 `src/*.mjs`、`remote/p0_runner.py`、`tests/`、`remote/tests/` 全文；三份原始 command receipts（含 Python ERROR 的完整 stderr、Windows `status` 的 stderr 与占用文件名）；N1/N4/N5 的定向用例输出；以及用户对 N6、N8 两项业务口径的书面确认。
5. 本席**未**与另一审计员交换结论，本报告不构成双席共识；双席一致或分歧都需编排者另行比对。