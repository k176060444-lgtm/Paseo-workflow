import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

BASE = Path('C:/Users/KK/AppData/Local/hermes/profiles/xiaoshitou/cache/scratch')
SOURCE = BASE / 'paseo-s0-8fe132-source'
TEST = BASE / 'paseo-s0-8fe132-test'
AUDIT = BASE / 'paseo-s0-8fe132-audit'
SHA = '8fe13211271dabc4de7a7ba02b9853f3d6196979'
raw = subprocess.check_output(['git', '-C', str(SOURCE), 'ls-tree', '-rz', '--full-tree', SHA])
items = []
for entry in raw.split(b'\0'):
    if not entry:
        continue
    metadata, name = entry.split(b'\t', 1)
    mode, typ, blob = metadata.decode('ascii').split(' ')
    path = name.decode('utf-8')
    if typ != 'blob':
        continue
    data = (SOURCE / Path(path)).read_bytes()
    actual = hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest()
    items.append({'path': path, 'size': len(data), 'git_blob': blob,
                  'checkout_git_blob': actual, 'sha256': hashlib.sha256(data).hexdigest(),
                  'blob_match': blob == actual})
manifest = {'commit': SHA, 'file_count': len(items), 'mismatch_count': sum(not i['blob_match'] for i in items),
            'files': items}
(AUDIT / 'source-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
print('source_manifest:', len(items), 'files; blob mismatches:', manifest['mismatch_count'])

# Process-local temp/cache settings keep npm bookkeeping inside the audit scratch area.
env = os.environ.copy()
env['npm_config_cache'] = str(AUDIT / 'npm-cache')
env['npm_config_logs_max'] = '0'
env['npm_config_update_notifier'] = 'false'
env['TMP'] = env['TEMP'] = env['TMPDIR'] = str(AUDIT)
commands = [['bash','-c','node --version'], ['bash','-c','npm --version'],
            ['bash','-c','npm run check'],
            ['bash','-c','python3 -m unittest discover -s remote/tests -v']]
receipts = []
for cmd in commands:
    start = time.monotonic()
    r = subprocess.run(cmd, cwd=TEST, env=env, capture_output=True, text=True,
                       encoding='utf-8', errors='replace', timeout=60)
    rec = {'command': cmd[-1], 'cwd': str(TEST), 'exit_code': r.returncode,
           'elapsed_seconds': round(time.monotonic()-start, 3), 'stdout': r.stdout, 'stderr': r.stderr}
    receipts.append(rec)
    print(json.dumps(rec, ensure_ascii=False))
(AUDIT / 'official-command-receipts.json').write_text(json.dumps(receipts, ensure_ascii=False, indent=2), encoding='utf-8')
