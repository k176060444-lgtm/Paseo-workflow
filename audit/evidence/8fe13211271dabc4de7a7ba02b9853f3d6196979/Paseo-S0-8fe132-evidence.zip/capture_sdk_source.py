import base64
import json
from pathlib import Path
import subprocess

COMMIT='6c1b48d2962ec6a48d5a553e312dfcc1f94e2e7a'
AUDIT=Path('C:/Users/KK/AppData/Local/hermes/profiles/xiaoshitou/cache/scratch/paseo-s0-8fe132-audit')
files=[('packages/client/package.json',[(1,8)]),('packages/client/src/index.ts',[(387,391),(1008,1016)]),
       ('packages/client/src/daemon-client.ts',[(6497,6518),(7685,7695)])]
rows=[]
for name,ranges in files:
    url=f'repos/getpaseo/paseo/contents/{name}?ref={COMMIT}'
    data=json.loads(subprocess.check_output(['gh','api',url],text=True,encoding='utf-8',timeout=60))
    lines=base64.b64decode(data['content']).decode('utf-8').splitlines()
    selected=[{'start':a,'end':b,'text':'\n'.join(f'{n}|{lines[n-1]}' for n in range(a,min(b,len(lines))+1))} for a,b in ranges]
    rows.append({'path':name,'git_blob':data['sha'],'ranges':selected})
obj={'repo':'getpaseo/paseo','commit':COMMIT,'files':rows}
(AUDIT/'sdk-source-receipt.json').write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(obj,ensure_ascii=False,indent=2))
