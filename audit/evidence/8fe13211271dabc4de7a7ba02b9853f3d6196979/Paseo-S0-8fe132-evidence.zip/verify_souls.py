import json
from pathlib import Path
import subprocess

BASE = Path('C:/Users/KK/AppData/Local/hermes/profiles/xiaoshitou/cache/scratch')
SOURCE = BASE / 'paseo-s0-8fe132-source'
AUDIT = BASE / 'paseo-s0-8fe132-audit'
SHA = '8fe13211271dabc4de7a7ba02b9853f3d6196979'
groups = [
    ('k176060444-lgtm/Hermes-Coding-Role-Souls', 'f0ecc4895c8947af164ff40ce1f2b29f52947b07', 'souls/',
     ['planner','worker','spec_reviewer','quality_reviewer','tester_gate_a','worker_remediation','tester_gate_b','arbitrator']),
    ('k176060444-lgtm/hermes-agent', '38c76de3f7e8b47951b01d430806fffe10fe1cdc', 'experiments/hermes-coding-pipeline-p1/souls/',
     ['blind_a','blind_b','blind_c']),
]
rows = []
for repo, commit, prefix, names in groups:
    url = f'repos/{repo}/git/trees/{commit}?recursive=1'
    result = subprocess.run(['gh','api',url], capture_output=True, text=True, encoding='utf-8', timeout=60)
    if result.returncode:
        raise RuntimeError(f'gh API failed: {repo}: {result.stderr}')
    tree = json.loads(result.stdout)
    if tree.get('truncated'):
        raise RuntimeError(f'truncated source tree: {repo}')
    paths = {x['path']:x['sha'] for x in tree['tree'] if x['type']=='blob'}
    for name in names:
        local_path = f'souls/{name}.md'
        actual = subprocess.check_output(['git','-C',str(SOURCE),'rev-parse',f'{SHA}:{local_path}'], text=True).strip()
        remote_path = f'{prefix}{name}.md'
        upstream = paths.get(remote_path)
        rows.append({'path':local_path,'git_blob':actual,'source_repo':repo,'source_commit':commit,
                     'source_path':remote_path,'source_blob':upstream,'match':actual==upstream})
report = {'rows':rows,'count':len(rows),'matches':sum(row['match'] for row in rows)}
(AUDIT/'soul-provenance-receipt.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
