// Offline synthetic probes. No real network, model, database, Git, or secret is used.
import fs from 'node:fs';
import {createHmac} from 'node:crypto';
import {SshP0Adapter} from '../paseo-s0-8fe132-source/src/p0.mjs';
import {WorkflowController} from '../paseo-s0-8fe132-source/src/controller.mjs';
import {PaseoAgentRuntime} from '../paseo-s0-8fe132-source/src/agents.mjs';
import {canonical,ROLE_PERMISSIONS,parseAgentOutput} from '../paseo-s0-8fe132-source/src/policy.mjs';

const originalRead = fs.readFileSync;
const syntheticKey = Buffer.alloc(40, 0x41);
fs.readFileSync = function(p,...args) {
  return String(p).startsWith('synthetic-key-') ? Buffer.from(syntheticKey) : originalRead.call(this,p,...args);
};
const allNodes=['synthetic-5','synthetic-9','synthetic-3'].map((id,i)=>({
  id,enabled:true,physicalId:'configured-'+i,hmacKeyPath:'synthetic-key-'+i,
  role:['blind_a','blind_b','blind_c'][i],harness:'synthetic',model:'synthetic/model',
  sshAlias:id,runner:'unused',config:'unused'
}));
const task={id:'TEST1234',frozen:{souls:{blind_a:{text:'a'},blind_b:{text:'b'},blind_c:{text:'c'}}}};
const fakeStore={artifact:()=>({sha256:'0'.repeat(64)}),recordIntent:()=>{},recordAck:()=>{},recordTerminal:()=>{}};
const commit='f'.repeat(40);
function fakeAdapter(nodes,mode){
  const adapter=new SshP0Adapter(nodes,{pollMs:0,extraThirdMs:0,deadlineMs:100,sleep:async()=>{}});
  const actions=[];const requests=new Map();
  adapter.ssh=async (node,action,spec)=>{
    actions.push(node.id+':'+action);
    if(action==='submit'){
      if(mode==='third-unavailable'&&node.id==='synthetic-3')throw Error('simulated third submit unavailable');
      requests.set(spec.jobId,spec);return {jobId:spec.jobId,status:'ACCEPTED'};
    }
    if(node.id==='synthetic-3'&&mode==='third-running')return {jobId:spec.jobId,status:'RUNNING'};
    const req=requests.get(spec.jobId);
    const body={jobId:spec.jobId,nodeId:node.id,commit:req.commit,model:node.model,harness:node.harness,
      exitCode:0,clean:true,stdoutSha256:'0'.repeat(64),findings:[],verdict:'PASS'};
    return {jobId:spec.jobId,status:'FINISHED',result:{body,mac:createHmac('sha256',syntheticKey).update(canonical(body)).digest('hex')}};
  };
  return {adapter,actions};
}
const results=[];
{
  const {adapter,actions}=fakeAdapter(allNodes.slice(0,2),'normal');
  const r=await adapter.review({task,commit,taskSpec:'synthetic',store:fakeStore,cycle:'same-key'});
  results.push({case:'same fake key bytes in two different fake paths',passed:r.passed,reportCount:r.reports.length,
    physicalIds:r.reports.map(x=>x.physicalId),actions});
}
{
  const {adapter,actions}=fakeAdapter(allNodes,'third-unavailable');let error='';
  try{await adapter.review({task,commit,taskSpec:'synthetic',store:fakeStore,cycle:'third-unavailable'});}catch(e){error=e.message;}
  results.push({case:'two submits accepted, optional third submit fails',error,actions});
}
{
  const {adapter,actions}=fakeAdapter(allNodes,'third-running');
  const r=await adapter.review({task,commit,taskSpec:'synthetic',store:fakeStore,cycle:'third-running'});
  results.push({case:'optional third still running when simulated grace expires',passed:r.passed,missing:r.missing,actions,
    note:'extraThirdMs=0 is synthetic; this is not a 600-second real-time test'});
}
{
  const store={verify:()=>({}),save:()=>{},artifact:()=>({sha256:'1'.repeat(64)})};
  const runtime={execute:async({role})=>({role,agentId:'synthetic-'+role,verdict:'PASS',
    findings:role==='spec_reviewer'?['BLOCKER: synthetic critical defect']:[]})};
  const gitOps={assertUnchanged:async()=>{}};
  const controller=new WorkflowController({store,runtime,p0:null,gitOps});
  const t={id:'TEST1234',stage:'A_REVIEW',status:'READY',aRound:1,bRound:0,currentSha:commit,
    worktree:'synthetic',taskSpec:'synthetic',history:[],frozen:{policy:{maxA:10,maxB:10,permissions:ROLE_PERMISSIONS}}};
  await controller.step(t);
  results.push({case:'reviewer PASS plus BLOCKER finding',stageAfter:t.stage,statusAfter:t.status});
}
{
  const outputs={};
  for(const verdict of ['APPROVE','REQUEST_CHANGES','PASS','FAIL']){
    try{parseAgentOutput(JSON.stringify({verdict,summary:'synthetic',findings:[]}), 'spec_reviewer');outputs[verdict]='accepted';}
    catch(e){outputs[verdict]='rejected: '+e.message;}
  }
  results.push({case:'Soul review verdicts versus JSON parser',outputs});
}
{
  let captured;
  const runtime=new PaseoAgentRuntime('synthetic');
  runtime.client={agents:{create:async()=>({id:'fake-id',waitForFinish:async arg=>{
    captured={argument:arg,argumentType:typeof arg,passesSdkNumberIsFinite:Number.isFinite(arg)};
    return {status:'idle',lastMessage:JSON.stringify({verdict:'PASS',summary:'synthetic',findings:[]})};
  }})}};
  const task={id:'TEST1234',frozen:{roles:{quality_reviewer:{model:'codex/synthetic',harness:'codex'}},
    souls:{quality_reviewer:{text:'synthetic',sha256:'0'.repeat(64)}}}};
  await runtime.execute({task,role:'quality_reviewer',phase:'synthetic',cwd:'synthetic',prompt:'synthetic',store:fakeStore});
  results.push({case:'Paseo waitForFinish argument (fake client only)',...captured});
}
fs.readFileSync=originalRead;
console.log(JSON.stringify({mode:'offline synthetic in-memory adapters',results},null,2));
